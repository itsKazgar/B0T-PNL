import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListBots, useStartBot, useStopBot, useListBotLogs, useGetEngineStatus,
  useGetStrategy,
  getListBotsQueryKey, getListBotLogsQueryKey, getGetEngineStatusQueryKey,
} from "@workspace/api-client-react";
import { Play, Square, Terminal, AlertTriangle, CheckCircle2, Circle, RefreshCw, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const LOCAL_SETUP = `# 1. Clone your repo
git clone <your-github-repo>
cd <repo-name> && pnpm install

# 2. Create .env file
cp .env.example .env
# Edit .env — add your values:
# DATABASE_URL=postgresql://...
# SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
# WALLET_PRIVATE_KEY=<base58-encoded-private-key>

# 3. Start API server (runs engine + bots)
pnpm --filter @workspace/api-server run dev

# 4. Start frontend
pnpm --filter @workspace/solana-trader run dev

# Bots auto-start if marked active in Strategy > Bots
# Engine polls every 30s — updates prices, fires TP/SL`;

const BOT_DESCRIPTIONS: Record<string, { desc: string; detail: string }> = {
  scalper: {
    desc: "Momentum scalper — enters on volume spike, exits at TP/SL",
    detail: "Scans PumpFun trending tokens every 30s. Opens positions on momentum signals. Auto-closes via monitor when TP or SL is hit.",
  },
  dca: {
    desc: "Dollar-cost average into a Jupiter token on a set interval",
    detail: "Buys a fixed USD amount of your target token at a regular interval. Useful for accumulating a position without timing the market.",
  },
  compound_guard: {
    desc: "Passive monitor — enforces TP/SL on all open positions",
    detail: "No new trades. Watches all open positions and auto-closes when take profit or stop loss targets are reached. Compound floor is always respected.",
  },
};

function LogLine({ log }: { log: { id: number; level: string; message: string; createdAt: string } }) {
  const levelColor = log.level === "trade" ? "profit" : log.level === "error" ? "loss" : log.level === "warn" ? "text-yellow-400" : "text-muted-foreground";
  const ts = new Date(log.createdAt).toLocaleTimeString("en-US", { hour12: false });
  return (
    <div className="flex gap-3 py-1 border-b border-border/40 last:border-0 font-mono text-xs">
      <span className="text-muted-foreground shrink-0 w-16">{ts}</span>
      <span className={cn("shrink-0 w-10 uppercase", levelColor)}>{log.level}</span>
      <span className="text-foreground leading-relaxed">{log.message}</span>
    </div>
  );
}

export default function BotsPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [showSetup, setShowSetup] = useState(false);

  const { data: bots, isLoading: botsLoading } = useListBots();
  const { data: logs, isLoading: logsLoading } = useListBotLogs({ limit: 40 });
  const { data: engine } = useGetEngineStatus();
  const { data: strategy } = useGetStrategy();
  const startBot = useStartBot();
  const stopBot = useStopBot();

  function invalidate() {
    qc.invalidateQueries({ queryKey: getListBotsQueryKey() });
    qc.invalidateQueries({ queryKey: getListBotLogsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetEngineStatusQueryKey() });
  }

  function handleToggle(id: number, active: boolean) {
    const action = active ? stopBot : startBot;
    action.mutate({ id }, {
      onSuccess: () => {
        toast({ title: active ? "Bot stopped" : "Bot started" });
        invalidate();
      },
      onError: () => toast({ title: "Error", variant: "destructive" }),
    });
  }

  const REQUIRED_ENVS = [
    { key: "SOLANA_RPC_URL", present: engine?.liveMode ?? false, label: "RPC endpoint" },
    { key: "WALLET_PRIVATE_KEY", present: engine?.liveMode ?? false, label: "Wallet private key" },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ bots</span></h1>
          <p className="font-mono text-xs text-muted-foreground mt-0.5">automated trading modules</p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="font-mono text-xs h-7 rounded-none" onClick={() => invalidate()} data-testid="button-refresh">
            <RefreshCw className="size-3 mr-1.5" />refresh
          </Button>
          <Button variant="outline" size="sm" className="font-mono text-xs h-7 rounded-none" onClick={() => setShowSetup(v => !v)} data-testid="button-setup">
            <Terminal className="size-3 mr-1.5" />local setup
          </Button>
        </div>
      </div>

      {/* Engine status bar */}
      <div className="border border-border bg-card px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4 font-mono text-xs">
          <div className="flex items-center gap-2">
            <div className={cn("size-1.5 rounded-full", engine?.running ? "bg-green-500" : "bg-muted-foreground")} />
            <span className="text-muted-foreground">engine</span>
            <span className={engine?.running ? "profit" : "text-muted-foreground"}>{engine?.running ? "running" : "stopped"}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <span>ticks:</span><span className="text-foreground">{engine?.tickCount ?? 0}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <span>mode:</span>
            <span className={engine?.liveMode ? "profit" : "text-yellow-400"}>{engine?.liveMode ? "live" : "paper"}</span>
          </div>
          {engine?.lastTickAt && (
            <div className="flex items-center gap-2 text-muted-foreground hidden md:flex">
              <span>last tick:</span>
              <span className="text-foreground">{new Date(engine.lastTickAt).toLocaleTimeString("en-US", { hour12: false })}</span>
            </div>
          )}
        </div>
      </div>

      {/* Paper trading banner or live trading status */}
      {!engine?.liveMode ? (
        <div className="border border-yellow-500/30 bg-yellow-500/5 p-4 flex items-start gap-3">
          <AlertTriangle className="size-4 text-yellow-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-mono text-sm font-medium text-yellow-400">paper trading mode</p>
            <p className="font-mono text-xs text-muted-foreground mt-0.5">
              Prices update in real-time via Jupiter API. Trades are simulated — no real swaps executed.
              Set <span className="text-foreground font-medium">SOLANA_RPC_URL</span> and <span className="text-foreground font-medium">WALLET_PRIVATE_KEY</span> to enable live trading.
            </p>
          </div>
        </div>
      ) : (
        <div className="border border-green-500/30 bg-green-500/5 p-4 flex items-center gap-3">
          <Zap className="size-4 text-green-500 shrink-0" />
          <p className="font-mono text-sm font-medium text-green-400">live trading mode — real swaps via Jupiter API</p>
        </div>
      )}

      {/* Local setup */}
      {showSetup && (
        <div className="border border-border bg-card">
          <div className="px-4 py-2 border-b border-border flex items-center gap-2">
            <Terminal className="size-3 text-primary" />
            <span className="font-mono text-xs text-muted-foreground">local setup</span>
          </div>
          <pre className="p-4 font-mono text-xs text-foreground overflow-x-auto leading-relaxed">{LOCAL_SETUP}</pre>
        </div>
      )}

      {/* Env status */}
      <div>
        <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-2">environment</p>
        <div className="border border-border divide-y divide-border">
          {REQUIRED_ENVS.map(e => (
            <div key={e.key} className="flex items-center justify-between px-4 py-2.5">
              <div className="flex items-center gap-3">
                {e.present
                  ? <CheckCircle2 className="size-3.5 text-green-500 shrink-0" />
                  : <Circle className="size-3.5 text-muted-foreground shrink-0" />}
                <div>
                  <p className="font-mono text-sm">{e.key}</p>
                  <p className="font-mono text-xs text-muted-foreground">{e.label}</p>
                </div>
              </div>
              <Badge variant="outline" className={cn("rounded-none font-mono text-xs", e.present ? "border-green-500/40 text-green-400" : "border-border text-muted-foreground")}>
                {e.present ? "set" : "missing"}
              </Badge>
            </div>
          ))}
        </div>
      </div>

      {/* Strategy summary */}
      {strategy && (
        <div>
          <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-2">bots inherit strategy</p>
          <div className="border border-border grid grid-cols-2 md:grid-cols-4 divide-x divide-border">
            {[
              ["slippage", `${strategy.slippagePct}%`],
              ["take profit", `+${strategy.defaultTakeProfitPct}%`],
              ["stop loss", `-${strategy.defaultStopLossPct}%`],
              ["floor", `${strategy.compoundFloorPct}% protected`],
            ].map(([k, v]) => (
              <div key={k} className="p-3 bg-card">
                <p className="font-mono text-xs text-muted-foreground">{k}</p>
                <p className="font-mono text-sm font-medium mt-0.5">{v}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Bot list */}
      <div>
        <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-2">bots ({bots?.length ?? 0})</p>
        {botsLoading ? <Skeleton className="h-48" /> : (
          <div className="border border-border divide-y divide-border">
            {bots?.map(bot => {
              const meta = BOT_DESCRIPTIONS[bot.type] ?? { desc: bot.type, detail: "" };
              return (
                <div key={bot.id} className={cn("p-4 transition-colors", bot.active ? "bg-primary/5" : "bg-card")} data-testid={`card-bot-${bot.id}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-mono text-sm font-medium">{bot.name}</p>
                        <Badge variant="outline" className={cn("rounded-none font-mono text-xs border", bot.source === "pumpfun" ? "border-orange-500/40 text-orange-400" : bot.source === "jupiter" ? "border-blue-500/40 text-blue-400" : "border-border text-muted-foreground")}>
                          {bot.source}
                        </Badge>
                        <Badge variant="outline" className="rounded-none font-mono text-xs border-border text-muted-foreground">{bot.type}</Badge>
                      </div>
                      <p className="font-mono text-xs text-muted-foreground mt-1">{meta.desc}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 ml-4">
                      <div className="flex items-center gap-1.5 font-mono text-xs">
                        <div className={cn("size-1.5 rounded-full", bot.active ? "bg-green-500" : "bg-muted-foreground")} />
                        <span className="text-muted-foreground">{bot.active ? "running" : "stopped"}</span>
                      </div>
                      <Button
                        variant={bot.active ? "destructive" : "outline"}
                        size="sm"
                        className="font-mono text-xs h-7 rounded-none"
                        onClick={() => handleToggle(bot.id, bot.active)}
                        disabled={startBot.isPending || stopBot.isPending}
                        data-testid={`button-toggle-${bot.id}`}
                      >
                        {bot.active
                          ? <><Square className="size-3 mr-1.5" />stop</>
                          : <><Play className="size-3 mr-1.5" />start</>}
                      </Button>
                    </div>
                  </div>
                  <p className="font-mono text-xs text-muted-foreground border-l-2 border-border pl-3 mb-2">{meta.detail}</p>
                  <div className="flex items-center gap-4 font-mono text-xs text-muted-foreground">
                    <span>trades: <span className="text-foreground">{bot.totalTrades}</span></span>
                    {bot.lastRunAt && <span>last run: <span className="text-foreground">{new Date(bot.lastRunAt).toLocaleTimeString("en-US", { hour12: false })}</span></span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Activity log */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest">activity log</p>
          <Button variant="ghost" size="sm" className="font-mono text-xs h-6 rounded-none" onClick={() => qc.invalidateQueries({ queryKey: getListBotLogsQueryKey() })} data-testid="button-refresh-logs">
            <RefreshCw className="size-3 mr-1" />refresh
          </Button>
        </div>
        <div className="border border-border bg-card p-3 max-h-72 overflow-y-auto">
          {logsLoading ? <Skeleton className="h-32" /> : !logs?.length ? (
            <p className="font-mono text-xs text-muted-foreground py-4 text-center">no activity yet — start a bot or wait for the monitor to tick</p>
          ) : (
            logs.map(log => <LogLine key={log.id} log={log} />)
          )}
        </div>
      </div>
    </div>
  );
}
