import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGetStrategy, useUpdateStrategy, getGetStrategyQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription, FormMessage } from "@/components/ui/form";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  slippagePct: z.coerce.number().min(0.1).max(50),
  defaultTakeProfitPct: z.coerce.number().min(1),
  defaultStopLossPct: z.coerce.number().min(1).max(100),
  maxPositionPct: z.coerce.number().min(1).max(100),
  maxOpenPositions: z.coerce.number().min(1).max(50),
  compoundFloorPct: z.coerce.number().min(0).max(99),
  autoTakeProfit: z.boolean(),
  autoStopLoss: z.boolean(),
});
type V = z.infer<typeof schema>;

function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between py-4 border-b border-border last:border-0">
      <div className="flex-1 mr-8">
        <p className="font-mono text-sm">{label}</p>
        {desc && <p className="font-mono text-xs text-muted-foreground mt-0.5">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export default function StrategyPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: s, isLoading } = useGetStrategy();
  const update = useUpdateStrategy();

  const form = useForm<V>({
    resolver: zodResolver(schema),
    defaultValues: { slippagePct: 10, defaultTakeProfitPct: 30, defaultStopLossPct: 15, maxPositionPct: 20, maxOpenPositions: 5, compoundFloorPct: 50, autoTakeProfit: true, autoStopLoss: true },
  });

  useEffect(() => {
    if (s) form.reset({ slippagePct: s.slippagePct, defaultTakeProfitPct: s.defaultTakeProfitPct, defaultStopLossPct: s.defaultStopLossPct, maxPositionPct: s.maxPositionPct, maxOpenPositions: s.maxOpenPositions, compoundFloorPct: s.compoundFloorPct, autoTakeProfit: s.autoTakeProfit, autoStopLoss: s.autoStopLoss });
  }, [s]);

  function onSubmit(v: V) {
    update.mutate({ data: v }, {
      onSuccess: () => { toast({ title: "strategy saved" }); qc.invalidateQueries({ queryKey: getGetStrategyQueryKey() }); },
      onError: () => toast({ title: "error", variant: "destructive" }),
    });
  }

  const floor = form.watch("compoundFloorPct");
  const maxPos = form.watch("maxPositionPct");

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-6 max-w-xl">
      <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ strategy</span></h1>

      {/* Floor visualizer */}
      <div className="border border-border bg-card p-4 space-y-2">
        <div className="flex justify-between font-mono text-xs text-muted-foreground">
          <span>compound floor — protected {floor.toFixed(0)}%</span>
          <span>tradeable {(100 - floor).toFixed(0)}%</span>
        </div>
        <div className="h-1.5 bg-muted overflow-hidden">
          <div className="h-full bg-primary transition-all" style={{ width: `${floor}%` }} />
        </div>
        <p className="font-mono text-xs text-muted-foreground">max per position: {maxPos}% · all bots inherit this</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="border border-border bg-card px-4">
            <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest py-3 border-b border-border">execution</p>
            <FormField control={form.control} name="slippagePct" render={({ field }) => (
              <Row label="slippage %" desc="10% default — higher fills at worse price">
                <Input {...field} type="number" step="0.1" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-slippage" />
              </Row>
            )} />
            <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest py-3 border-b border-border">default trade params</p>
            <FormField control={form.control} name="defaultTakeProfitPct" render={({ field }) => (
              <Row label="take profit %" desc="default TP for new trades and bots">
                <Input {...field} type="number" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-tp" />
              </Row>
            )} />
            <FormField control={form.control} name="defaultStopLossPct" render={({ field }) => (
              <Row label="stop loss %" desc="default SL — never skip this">
                <Input {...field} type="number" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-sl" />
              </Row>
            )} />
            <FormField control={form.control} name="autoTakeProfit" render={({ field }) => (
              <Row label="auto take profit" desc="bots close position at TP target">
                <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-atp" />
              </Row>
            )} />
            <FormField control={form.control} name="autoStopLoss" render={({ field }) => (
              <Row label="auto stop loss" desc="bots close position at SL target">
                <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-asl" />
              </Row>
            )} />
            <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest py-3 border-b border-border">position sizing</p>
            <FormField control={form.control} name="maxPositionPct" render={({ field }) => (
              <Row label="max position %" desc="never go all-in — cap per trade">
                <Input {...field} type="number" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-maxpos" />
              </Row>
            )} />
            <FormField control={form.control} name="maxOpenPositions" render={({ field }) => (
              <Row label="max open positions" desc="limit concurrent exposure">
                <Input {...field} type="number" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-maxopen" />
              </Row>
            )} />
            <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest py-3 border-b border-border">compound floor</p>
            <FormField control={form.control} name="compoundFloorPct" render={({ field }) => (
              <Row label="protected floor %" desc="this % of portfolio is never touched">
                <Input {...field} type="number" step="5" min="0" max="99" className="w-24 h-7 font-mono text-xs rounded-none text-right" data-testid="input-floor" />
              </Row>
            )} />
          </div>

          <Button type="submit" className="w-full mt-4 font-mono text-xs h-9 rounded-none" disabled={update.isPending} data-testid="button-save">
            {update.isPending ? "saving..." : "save strategy"}
          </Button>
        </form>
      </Form>
    </div>
  );
}
