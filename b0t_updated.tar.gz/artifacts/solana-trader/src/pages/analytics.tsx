import { useState } from "react";
import { useGetAnalyticsSummary, useGetPnlHistory, useGetWinsLosses } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip as RT, ResponsiveContainer, CartesianGrid, Cell,
} from "recharts";

export default function AnalyticsPage() {
  const [days, setDays] = useState(30);
  const { data: s } = useGetAnalyticsSummary();
  const { data: pnl } = useGetPnlHistory({ days });
  const { data: wl } = useGetWinsLosses();

  const pnlData = pnl?.map(p => ({ date: p.date.slice(5), pnl: +p.cumulativePnl.toFixed(2), daily: +p.dailyPnl.toFixed(2) })) ?? [];

  const ttStyle = { background: "hsl(220 13% 11%)", border: "1px solid hsl(220 13% 16%)", borderRadius: 2, fontFamily: "Ubuntu Mono, monospace", fontSize: 11 };

  return (
    <div className="space-y-8">
      <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ analytics</span></h1>

      {/* Stats row */}
      {s && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border">
          {[
            { label: "win rate", value: `${s.winRate.toFixed(1)}%`, sub: `${s.winCount}W ${s.lossCount}L`, hl: null },
            { label: "realized pnl", value: `${s.totalRealizedPnl >= 0 ? "+" : ""}$${s.totalRealizedPnl.toFixed(2)}`, sub: `${s.totalTradesCount} trades`, hl: s.totalRealizedPnl >= 0 ? "profit" : "loss" },
            { label: "compound growth", value: `${s.compoundGrowthPct >= 0 ? "+" : ""}${s.compoundGrowthPct.toFixed(1)}%`, sub: `$${s.startingCapital} → $${s.currentCapital.toFixed(0)}`, hl: s.compoundGrowthPct >= 0 ? "profit" : "loss" },
            { label: "best trade", value: `+${s.bestTrade.toFixed(1)}%`, sub: `worst: ${s.worstTrade.toFixed(1)}%`, hl: "profit" },
          ].map(({ label, value, sub, hl }) => (
            <div key={label} className="bg-card p-4">
              <p className="font-mono text-xs text-muted-foreground">{label}</p>
              <p className={cn("font-mono text-xl font-bold mt-1", hl === "profit" ? "profit" : hl === "loss" ? "loss" : "")}>{value}</p>
              <p className="font-mono text-xs text-muted-foreground mt-0.5">{sub}</p>
            </div>
          ))}
        </div>
      )}

      {/* P&L chart */}
      <div className="border border-border bg-card p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">cumulative pnl</span>
          <div className="flex gap-1">
            {[7, 14, 30, 90].map(d => (
              <Button key={d} variant={days === d ? "default" : "ghost"} size="sm" className="h-6 font-mono text-xs rounded-none px-2" onClick={() => setDays(d)} data-testid={`btn-days-${d}`}>{d}d</Button>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={pnlData}>
            <CartesianGrid strokeDasharray="2 2" stroke="hsl(220 13% 14%)" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fontFamily: "Ubuntu Mono", fill: "hsl(220 10% 50%)" }} />
            <YAxis tick={{ fontSize: 10, fontFamily: "Ubuntu Mono", fill: "hsl(220 10% 50%)" }} tickFormatter={v => `$${v}`} />
            <RT contentStyle={ttStyle} formatter={(v: number) => [`$${v.toFixed(2)}`, "pnl"]} />
            <Line type="monotone" dataKey="pnl" stroke="hsl(21 87% 52%)" strokeWidth={1.5} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Daily bars + win/loss */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="border border-border bg-card p-4">
          <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">daily pnl (14d)</p>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={pnlData.slice(-14)}>
              <CartesianGrid strokeDasharray="2 2" stroke="hsl(220 13% 14%)" />
              <XAxis dataKey="date" tick={{ fontSize: 9, fontFamily: "Ubuntu Mono", fill: "hsl(220 10% 50%)" }} />
              <YAxis tick={{ fontSize: 9, fontFamily: "Ubuntu Mono", fill: "hsl(220 10% 50%)" }} tickFormatter={v => `$${v}`} />
              <RT contentStyle={ttStyle} formatter={(v: number) => [`$${v.toFixed(2)}`, "daily"]} />
              <Bar dataKey="daily" radius={0}>
                {pnlData.slice(-14).map((entry, i) => (
                  <Cell key={i} fill={entry.daily >= 0 ? "hsl(142 71% 45%)" : "hsl(0 72% 51%)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-border bg-card p-4">
          <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">breakdown</p>
          {wl && (
            <div className="space-y-3 font-mono text-sm">
              {[
                { label: "wins", value: wl.wins, color: "profit" },
                { label: "losses", value: wl.losses, color: "loss" },
                { label: "jupiter trades", value: wl.jupiterTrades, color: "" },
                { label: "pumpfun trades", value: wl.pumpfunTrades, color: "" },
                { label: "avg hold time", value: `${wl.avgHoldTimeHours.toFixed(1)}h`, color: "" },
              ].map(({ label, value, color }) => (
                <div key={label} className="flex items-center justify-between py-1.5 border-b border-border/60 last:border-0">
                  <span className="text-muted-foreground text-xs">{label}</span>
                  <span className={cn("font-medium", color)}>{value}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
