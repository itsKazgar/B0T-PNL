import { useState, useEffect } from "react";
import { useListJupiterTokens, useListPumpFunTokens } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Search, ExternalLink, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const fmt = (n: number) => n >= 1e9 ? `${(n/1e9).toFixed(2)}B` : n >= 1e6 ? `${(n/1e6).toFixed(1)}M` : n >= 1e3 ? `${(n/1e3).toFixed(0)}K` : n.toFixed(2);
const fmtPrice = (n: number) => n < 0.000001 ? n.toExponential(2) : n < 0.001 ? n.toFixed(7) : n < 1 ? n.toFixed(4) : n.toFixed(2);
const pctClass = (v?: number | null) => v == null ? "text-muted-foreground" : v >= 0 ? "profit" : "loss";
const pctFmt = (v?: number | null) => v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(1)}%`;

const COL = "grid grid-cols-12 px-4 py-2 font-mono text-xs";

function TableHead({ cols }: { cols: { label: string; span: number; right?: boolean }[] }) {
  return (
    <div className={cn(COL, "text-muted-foreground uppercase tracking-widest border-b border-border bg-muted/10")}>
      {cols.map(c => (
        <span key={c.label} className={cn(`col-span-${c.span}`, c.right && "text-right")}>{c.label}</span>
      ))}
    </div>
  );
}

// ── CoinGecko ────────────────────────────────────────────────────────────────
interface CgToken { id: string; symbol: string; name: string; current_price: number; market_cap: number; total_volume: number; price_change_percentage_24h: number; image: string; }

function CoinGeckoTab() {
  const [data, setData] = useState<CgToken[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true); setError("");
    try {
      const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";
      const res = await fetch(`${API_BASE}/tokens/coingecko?limit=20`);
      if (!res.ok) throw new Error(`${res.status}`);
      setData(await res.json());
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="font-mono text-xs text-muted-foreground">live · coingecko</span>
        <Button variant="ghost" size="sm" className="h-7 font-mono text-xs rounded-none px-2" onClick={load}>
          <RefreshCw className="size-3 mr-1.5" />refresh
        </Button>
      </div>
      {loading ? <Skeleton className="h-64" /> : error ? (
        <p className="font-mono text-xs text-destructive py-4">{error}</p>
      ) : (
        <div className="border border-border divide-y divide-border">
          <TableHead cols={[
            { label: "token", span: 4 },
            { label: "price", span: 2, right: true },
            { label: "24h", span: 2, right: true },
            { label: "vol 24h", span: 2, right: true },
            { label: "mcap", span: 2, right: true },
          ]} />
          {data.map(t => (
            <div key={t.id} className={cn(COL, "hover:bg-muted/20 transition-colors items-center py-2.5")}>
              <div className="col-span-4 flex items-center gap-2">
                {t.image && <img src={t.image} alt={t.symbol} className="size-4 rounded-full" />}
                <div>
                  <p className="font-medium uppercase">{t.symbol}</p>
                  <p className="text-muted-foreground text-[10px] truncate">{t.name}</p>
                </div>
              </div>
              <span className="col-span-2 text-right">${fmtPrice(t.current_price)}</span>
              <span className={cn("col-span-2 text-right", pctClass(t.price_change_percentage_24h))}>
                {pctFmt(t.price_change_percentage_24h)}
              </span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(t.total_volume)}</span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(t.market_cap)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── DEX Screener ─────────────────────────────────────────────────────────────
interface DexPair {
  pairAddress: string; dexId: string;
  baseToken: { symbol: string; name: string; address: string };
  quoteToken: { symbol: string };
  priceUsd: string; volume: { h24: number };
  priceChange: { h1: number; h24: number };
  liquidity: { usd: number }; fdv: number;
}

function DexScreenerTab() {
  const [data, setData] = useState<DexPair[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");

  const load = async (query = "") => {
    setLoading(true); setError("");
    try {
      const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";
      const res = await fetch(`${API_BASE}/tokens/dexscreener?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error(`${res.status}`);
      setData(await res.json());
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === "Enter" && load(q)}
            placeholder="search pair..." className="pl-8 h-8 font-mono text-xs rounded-none" />
        </div>
        <Button variant="ghost" size="sm" className="h-8 font-mono text-xs rounded-none px-3" onClick={() => load(q)}>search</Button>
        <span className="font-mono text-xs text-muted-foreground ml-auto">live · solana · dexscreener</span>
      </div>
      {loading ? <Skeleton className="h-64" /> : error ? (
        <p className="font-mono text-xs text-destructive py-4">{error}</p>
      ) : (
        <div className="border border-border divide-y divide-border">
          <TableHead cols={[
            { label: "pair", span: 4 },
            { label: "price", span: 2, right: true },
            { label: "1h", span: 1, right: true },
            { label: "24h", span: 1, right: true },
            { label: "vol 24h", span: 2, right: true },
            { label: "liq", span: 2, right: true },
          ]} />
          {data.map(p => (
            <div key={p.pairAddress} className={cn(COL, "hover:bg-muted/20 transition-colors items-center py-2.5")}>
              <div className="col-span-4">
                <div className="flex items-center gap-1.5">
                  <p className="font-medium">{p.baseToken.symbol}<span className="text-muted-foreground">/{p.quoteToken.symbol}</span></p>
                  <a href={`https://dexscreener.com/solana/${p.pairAddress}`} target="_blank" rel="noreferrer">
                    <ExternalLink className="size-3 text-muted-foreground hover:text-foreground" />
                  </a>
                </div>
                <p className="text-[10px] text-muted-foreground">{p.dexId}</p>
              </div>
              <span className="col-span-2 text-right">${fmtPrice(parseFloat(p.priceUsd))}</span>
              <span className={cn("col-span-1 text-right", pctClass(p.priceChange?.h1))}>{pctFmt(p.priceChange?.h1)}</span>
              <span className={cn("col-span-1 text-right", pctClass(p.priceChange?.h24))}>{pctFmt(p.priceChange?.h24)}</span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(p.volume?.h24 ?? 0)}</span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(p.liquidity?.usd ?? 0)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Jupiter ──────────────────────────────────────────────────────────────────
function JupiterTab() {
  const [q, setQ] = useState("");
  const { data: jup, isLoading } = useListJupiterTokens({ q, limit: 20 });

  return (
    <div className="space-y-3">
      <div className="relative max-w-xs">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
        <Input value={q} onChange={e => setQ(e.target.value)} placeholder="search..." className="pl-8 h-8 font-mono text-xs rounded-none" />
      </div>
      {isLoading ? <Skeleton className="h-64" /> : (
        <div className="border border-border divide-y divide-border">
          <TableHead cols={[
            { label: "token", span: 4 },
            { label: "price", span: 2, right: true },
            { label: "24h", span: 2, right: true },
            { label: "mcap", span: 2, right: true },
            { label: "", span: 2 },
          ]} />
          {jup?.map(t => (
            <div key={t.mint} className={cn(COL, "hover:bg-muted/20 transition-colors items-center py-2.5")}>
              <div className="col-span-4"><p className="font-medium">{t.symbol}</p><p className="text-muted-foreground text-[10px]">{t.name}</p></div>
              <span className="col-span-2 text-right">${fmtPrice(t.priceUsd)}</span>
              <span className={cn("col-span-2 text-right", pctClass(t.change24h))}>{pctFmt(t.change24h)}</span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(t.marketCap)}</span>
              <div className="col-span-2 text-right">
                <Link href="/trade"><Button variant="ghost" size="sm" className="h-6 font-mono text-xs rounded-none px-2">trade</Button></Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── PumpFun ──────────────────────────────────────────────────────────────────
function PumpFunTab() {
  const [sort, setSort] = useState<"trending" | "new" | "volume">("trending");
  const { data: pump, isLoading } = useListPumpFunTokens({ limit: 20, sort });

  return (
    <div className="space-y-3">
      <div className="flex gap-1">
        {(["trending", "new", "volume"] as const).map(s => (
          <Button key={s} variant={sort === s ? "default" : "ghost"} size="sm"
            className="h-7 font-mono text-xs rounded-none px-3" onClick={() => setSort(s)}>{s}</Button>
        ))}
      </div>
      {isLoading ? <Skeleton className="h-64" /> : (
        <div className="border border-border divide-y divide-border">
          <TableHead cols={[
            { label: "token", span: 4 },
            { label: "price", span: 2, right: true },
            { label: "1h", span: 2, right: true },
            { label: "mcap", span: 2, right: true },
            { label: "bonding", span: 2, right: true },
          ]} />
          {pump?.map(t => (
            <div key={t.mint} className={cn(COL, "hover:bg-muted/20 transition-colors items-center py-2.5")}>
              <div className="col-span-4">
                <p className="font-medium text-orange-300">{t.symbol}</p>
                <p className="text-muted-foreground text-[10px] truncate">{t.name}</p>
              </div>
              <span className="col-span-2 text-right">${fmtPrice(t.priceUsd)}</span>
              <span className={cn("col-span-2 text-right", pctClass(t.change1h))}>{pctFmt(t.change1h)}</span>
              <span className="col-span-2 text-right text-muted-foreground">{fmt(t.marketCap)}</span>
              <div className="col-span-2 flex items-center justify-end gap-1.5">
                <div className="w-10 h-1 bg-muted overflow-hidden">
                  <div className="h-full bg-orange-500/70" style={{ width: `${Math.min(t.bondingCurvePct, 100)}%` }} />
                </div>
                <span className="text-muted-foreground">{t.bondingCurvePct.toFixed(0)}%</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────
export default function TokensPage() {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ tokens</span></h1>
        <div className="flex gap-1.5">
          <Badge variant="outline" className="font-mono text-[10px] rounded-none border-green-500/30 text-green-400">CoinGecko</Badge>
          <Badge variant="outline" className="font-mono text-[10px] rounded-none border-purple-500/30 text-purple-400">DexScreener</Badge>
        </div>
      </div>

      <Tabs defaultValue="coingecko">
        <TabsList className="rounded-none h-8 grid w-fit grid-cols-4">
          {["coingecko", "dexscreener", "jupiter", "pumpfun"].map(tab => (
            <TabsTrigger key={tab} value={tab} className="font-mono text-xs rounded-none px-4">{tab}</TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="coingecko" className="mt-4"><CoinGeckoTab /></TabsContent>
        <TabsContent value="dexscreener" className="mt-4"><DexScreenerTab /></TabsContent>
        <TabsContent value="jupiter" className="mt-4"><JupiterTab /></TabsContent>
        <TabsContent value="pumpfun" className="mt-4"><PumpFunTab /></TabsContent>
      </Tabs>
    </div>
  );
}
