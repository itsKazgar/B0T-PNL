import { useState } from "react";
import { useListPositions, useClosePosition, useUpdatePosition, getListPositionsQueryKey, getGetPortfolioQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Check, Edit2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function PositionsPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: positions, isLoading } = useListPositions();
  const closePos = useClosePosition();
  const updatePos = useUpdatePosition();
  const [editing, setEditing] = useState<number | null>(null);
  const [editTp, setEditTp] = useState("");
  const [editSl, setEditSl] = useState("");

  function inv() {
    qc.invalidateQueries({ queryKey: getListPositionsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetPortfolioQueryKey() });
  }

  function close(id: number) {
    closePos.mutate({ id }, {
      onSuccess: () => { toast({ title: "position closed" }); inv(); },
      onError: () => toast({ title: "error", variant: "destructive" }),
    });
  }

  function save(id: number) {
    updatePos.mutate({ id, data: { takeProfitPct: Number(editTp), stopLossPct: Number(editSl) } }, {
      onSuccess: () => { toast({ title: "targets updated" }); setEditing(null); inv(); },
      onError: () => toast({ title: "error", variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ positions ({positions?.length ?? 0})</span></h1>
        <Link href="/trade"><Button size="sm" className="font-mono text-xs h-7 rounded-none">+ new trade</Button></Link>
      </div>

      {isLoading ? <Skeleton className="h-48" /> : !positions?.length ? (
        <div className="border border-border p-8 text-center">
          <p className="font-mono text-xs text-muted-foreground mb-3">no open positions</p>
          <Link href="/trade"><Button size="sm" className="font-mono text-xs rounded-none">open first trade</Button></Link>
        </div>
      ) : (
        <div className="border border-border divide-y divide-border">
          {positions.map(pos => (
            <div key={pos.id} className="p-4" data-testid={`card-position-${pos.id}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-base">{pos.tokenSymbol}</span>
                  <Badge variant="outline" className={cn("rounded-none font-mono text-xs border", pos.source === "pumpfun" ? "border-orange-500/40 text-orange-400" : "border-blue-500/40 text-blue-400")}>
                    {pos.source}
                  </Badge>
                </div>
                <div className="text-right">
                  <p className={cn("font-mono text-lg font-bold", pos.unrealizedPnlPct >= 0 ? "profit" : "loss")}>
                    {pos.unrealizedPnlPct >= 0 ? "+" : ""}{pos.unrealizedPnlPct.toFixed(2)}%
                  </p>
                  <p className={cn("font-mono text-xs", pos.unrealizedPnl >= 0 ? "profit" : "loss")}>
                    {pos.unrealizedPnl >= 0 ? "+" : ""}${pos.unrealizedPnl.toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 font-mono text-xs mb-3">
                <div><p className="text-muted-foreground">entry</p><p className="mt-0.5">${pos.entryPrice < 0.01 ? pos.entryPrice.toFixed(6) : pos.entryPrice.toFixed(4)}</p></div>
                <div><p className="text-muted-foreground">current</p><p className="mt-0.5">${pos.currentPrice < 0.01 ? pos.currentPrice.toFixed(6) : pos.currentPrice.toFixed(4)}</p></div>
                <div><p className="text-muted-foreground">size</p><p className="mt-0.5">${pos.sizeUsd.toFixed(2)}</p></div>
              </div>

              {pos.thesis && (
                <p className="font-mono text-xs text-muted-foreground border-l-2 border-primary/30 pl-3 mb-3 leading-relaxed">{pos.thesis}</p>
              )}

              {editing === pos.id ? (
                <div className="flex items-end gap-2 mb-3">
                  <div><p className="font-mono text-xs text-muted-foreground mb-1">tp %</p><Input value={editTp} onChange={e => setEditTp(e.target.value)} className="h-7 w-20 font-mono text-xs rounded-none" data-testid="input-tp" /></div>
                  <div><p className="font-mono text-xs text-muted-foreground mb-1">sl %</p><Input value={editSl} onChange={e => setEditSl(e.target.value)} className="h-7 w-20 font-mono text-xs rounded-none" data-testid="input-sl" /></div>
                  <Button size="sm" className="h-7 font-mono text-xs rounded-none" onClick={() => save(pos.id)} disabled={updatePos.isPending} data-testid={`button-save-${pos.id}`}><Check className="size-3 mr-1" />save</Button>
                  <Button size="sm" variant="ghost" className="h-7 font-mono text-xs rounded-none" onClick={() => setEditing(null)}>cancel</Button>
                </div>
              ) : (
                <div className="flex items-center gap-2 font-mono text-xs mb-3">
                  <span className="text-muted-foreground">tp:</span>
                  <span className="profit">+{pos.takeProfitPct}%</span>
                  <span className="text-muted-foreground ml-2">sl:</span>
                  <span className="loss">-{pos.stopLossPct}%</span>
                </div>
              )}

              <div className="flex gap-2">
                {editing !== pos.id && (
                  <Button variant="outline" size="sm" className="h-7 font-mono text-xs rounded-none" onClick={() => { setEditing(pos.id); setEditTp(String(pos.takeProfitPct)); setEditSl(String(pos.stopLossPct)); }} data-testid={`button-edit-${pos.id}`}>
                    <Edit2 className="size-3 mr-1" />edit
                  </Button>
                )}
                <Button variant="destructive" size="sm" className="h-7 font-mono text-xs rounded-none" onClick={() => close(pos.id)} disabled={closePos.isPending} data-testid={`button-close-${pos.id}`}>
                  <X className="size-3 mr-1" />close
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
