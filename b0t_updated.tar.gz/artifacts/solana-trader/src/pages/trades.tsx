import { useState } from "react";
import { useListTrades } from "@workspace/api-client-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export default function TradesPage() {
  const [status, setStatus] = useState("all");
  const { data: trades, isLoading } = useListTrades(status !== "all" ? { status: status as "open" | "closed" | "cancelled" } : {});

  const closed = trades?.filter(t => t.status === "closed") ?? [];
  const realizedPnl = closed.reduce((s, t) => s + (t.pnlUsd ?? 0), 0);
  const wins = closed.filter(t => (t.pnlPct ?? 0) > 0).length;
  const losses = closed.filter(t => (t.pnlPct ?? 0) < 0).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ history</span></h1>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-32 h-7 font-mono text-xs rounded-none" data-testid="select-filter">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all" className="font-mono text-xs">all</SelectItem>
            <SelectItem value="open" className="font-mono text-xs">open</SelectItem>
            <SelectItem value="closed" className="font-mono text-xs">closed</SelectItem>
            <SelectItem value="cancelled" className="font-mono text-xs">cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary */}
      {trades && trades.length > 0 && (
        <div className="grid grid-cols-3 gap-px bg-border">
          <div className="bg-card p-3"><p className="font-mono text-xs text-muted-foreground">realized pnl</p><p className={cn("font-mono text-lg font-bold mt-1", realizedPnl >= 0 ? "profit" : "loss")}>{realizedPnl >= 0 ? "+" : ""}${realizedPnl.toFixed(2)}</p></div>
          <div className="bg-card p-3"><p className="font-mono text-xs text-muted-foreground">wins</p><p className="font-mono text-lg font-bold profit mt-1">{wins}</p></div>
          <div className="bg-card p-3"><p className="font-mono text-xs text-muted-foreground">losses</p><p className="font-mono text-lg font-bold loss mt-1">{losses}</p></div>
        </div>
      )}

      {isLoading ? <Skeleton className="h-64" /> : !trades?.length ? (
        <p className="font-mono text-xs text-muted-foreground py-8 text-center">no trades</p>
      ) : (
        <div className="border border-border divide-y divide-border">
          {/* Header */}
          <div className="grid grid-cols-12 px-4 py-2 text-xs font-mono text-muted-foreground uppercase tracking-widest">
            <span className="col-span-2">token</span>
            <span className="col-span-2">source</span>
            <span className="col-span-2 text-right">entry</span>
            <span className="col-span-2 text-right">size</span>
            <span className="col-span-2 text-right">pnl</span>
            <span className="col-span-2 text-right">status</span>
          </div>
          {trades.map(t => (
            <div key={t.id} className="grid grid-cols-12 px-4 py-3 text-xs font-mono hover:bg-muted/20 transition-colors items-center" data-testid={`row-trade-${t.id}`}>
              <div className="col-span-2">
                <p className="font-medium">{t.tokenSymbol}</p>
                <p className="text-muted-foreground truncate max-w-[80px]">{t.tokenName}</p>
              </div>
              <div className="col-span-2">
                <Badge variant="outline" className={cn("rounded-none border text-xs", t.source === "pumpfun" ? "border-orange-500/40 text-orange-400" : "border-blue-500/40 text-blue-400")}>
                  {t.source}
                </Badge>
              </div>
              <span className="col-span-2 text-right text-muted-foreground">${t.entryPrice < 0.01 ? t.entryPrice.toFixed(6) : t.entryPrice.toFixed(4)}</span>
              <span className="col-span-2 text-right">${t.sizeUsd.toFixed(0)}</span>
              <span className={cn("col-span-2 text-right font-medium", t.pnlUsd !== null && t.pnlUsd !== undefined ? (t.pnlUsd >= 0 ? "profit" : "loss") : "text-muted-foreground")}>
                {t.pnlUsd !== null && t.pnlUsd !== undefined ? `${t.pnlUsd >= 0 ? "+" : ""}$${t.pnlUsd.toFixed(2)}` : "—"}
              </span>
              <div className="col-span-2 text-right">
                <Badge variant="outline" className={cn("rounded-none border text-xs", t.status === "open" ? "border-primary/40 text-primary" : t.status === "closed" ? "border-border text-muted-foreground" : "border-yellow-500/40 text-yellow-400")}>
                  {t.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Thesis preview for latest trade */}
      {trades && trades[0]?.thesis && (
        <div className="border border-border p-4">
          <p className="font-mono text-xs text-muted-foreground mb-1">latest trade thesis — {trades[0].tokenSymbol}</p>
          <p className="font-mono text-sm leading-relaxed border-l-2 border-primary/30 pl-3">{trades[0].thesis}</p>
        </div>
      )}
    </div>
  );
}
