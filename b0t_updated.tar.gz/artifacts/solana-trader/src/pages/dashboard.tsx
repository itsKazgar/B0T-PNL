import { useGetPortfolio, useListPositions, useListTrades, getGetPortfolioQueryKey, getListPositionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function Row({ label, value, highlight }: { label: string; value: string; highlight?: "profit" | "loss" | null }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-border/60 last:border-0">
      <span className="font-mono text-xs text-muted-foreground">{label}</span>
      <span className={cn("font-mono text-sm font-medium", highlight === "profit" ? "profit" : highlight === "loss" ? "loss" : "text-foreground")}>
        {value}
      </span>
    </div>
  );
}

export default function Dashboard() {
  const qc = useQueryClient();
  const { data: p, isLoading: pl } = useGetPortfolio();
  const { data: positions, isLoading: posl } = useListPositions();
  const { data: trades, isLoading: tl } = useListTrades({ limit: 8 });

  const usd = (v?: number) => v !== undefined ? `$${v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—";
  const tradeable = p ? p.totalValueUsd - p.compoundFloorUsd : 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono text-xl font-bold text-foreground">B0T <span className="text-muted-foreground font-normal text-sm">/ dashboard</span></h1>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="font-mono text-xs h-7" onClick={() => {
            qc.invalidateQueries({ queryKey: getGetPortfolioQueryKey() });
            qc.invalidateQueries({ queryKey: getListPositionsQueryKey() });
          }} data-testid="button-refresh">
            <RefreshCw className="size-3 mr-1.5" />refresh
          </Button>
          <Link href="/trade">
            <Button size="sm" className="font-mono text-xs h-7" data-testid="button-new-trade">+ new trade</Button>
          </Link>
        </div>
      </div>

      {/* Portfolio block */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border">
        {[
          { label: "total value", value: usd(p?.totalValueUsd), hl: null },
          { label: "realized pnl", value: usd(p?.realizedPnl), hl: p ? (p.realizedPnl >= 0 ? "profit" : "loss") : null },
          { label: "unrealized pnl", value: usd(p?.unrealizedPnl), hl: p ? (p.unrealizedPnl >= 0 ? "profit" : "loss") : null },
        ].map(({ label, value, hl }) => (
          <div key={label} className="bg-card p-4">
            {pl ? <Skeleton className="h-9 w-32" /> : (
              <>
                <p className="font-mono text-xs text-muted-foreground mb-1">{label}</p>
                <p className={cn("font-mono text-2xl font-bold", hl === "profit" ? "profit" : hl === "loss" ? "loss" : "")}>{value}</p>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Compound floor */}
      {p && (
        <div className="bg-card border border-border p-4 space-y-2" data-testid="card-compound-floor">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-muted-foreground">compound floor</span>
            <span className="font-mono text-xs text-primary">{((p.compoundFloorUsd / p.totalValueUsd) * 100).toFixed(0)}% protected</span>
          </div>
          <div className="h-1.5 bg-muted rounded-none overflow-hidden">
            <div className="h-full bg-primary transition-all" style={{ width: `${(p.compoundFloorUsd / p.totalValueUsd) * 100}%` }} />
          </div>
          <div className="flex justify-between font-mono text-xs text-muted-foreground">
            <span>locked {usd(p.compoundFloorUsd)}</span>
            <span>tradeable {usd(tradeable)}</span>
          </div>
        </div>
      )}

      {/* Open positions */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">open positions ({positions?.length ?? 0})</span>
          <Link href="/positions"><span className="font-mono text-xs text-primary cursor-pointer hover:underline">view all →</span></Link>
        </div>
        {posl ? <Skeleton className="h-24" /> : !positions?.length ? (
          <p className="font-mono text-xs text-muted-foreground py-4">no open positions</p>
        ) : (
          <div className="border border-border divide-y divide-border">
            {positions.map(pos => (
              <div key={pos.id} className="flex items-center justify-between px-4 py-3 hover:bg-muted/20 transition-colors" data-testid={`row-position-${pos.id}`}>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-bold">{pos.tokenSymbol}</span>
                  <Badge variant="outline" className={cn("text-xs font-mono rounded-none border", pos.source === "pumpfun" ? "border-orange-500/40 text-orange-400" : "border-blue-500/40 text-blue-400")}>
                    {pos.source === "pumpfun" ? "pump" : "jup"}
                  </Badge>
                </div>
                <div className="flex items-center gap-6 font-mono text-xs">
                  <span className="text-muted-foreground">{usd(pos.sizeUsd)}</span>
                  <span className={cn("font-medium", pos.unrealizedPnlPct >= 0 ? "profit" : "loss")}>
                    {pos.unrealizedPnlPct >= 0 ? "+" : ""}{pos.unrealizedPnlPct.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent trades */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">recent trades</span>
          <Link href="/trades"><span className="font-mono text-xs text-primary cursor-pointer hover:underline">view all →</span></Link>
        </div>
        {tl ? <Skeleton className="h-32" /> : !trades?.length ? (
          <p className="font-mono text-xs text-muted-foreground py-4">no trades yet</p>
        ) : (
          <div className="border border-border divide-y divide-border">
            {trades.map(t => (
              <div key={t.id} className="flex items-center justify-between px-4 py-2.5 hover:bg-muted/20 transition-colors text-xs font-mono" data-testid={`row-trade-${t.id}`}>
                <div className="flex items-center gap-3">
                  <span className="font-bold">{t.tokenSymbol}</span>
                  <Badge variant="outline" className={cn("rounded-none border text-xs", t.source === "pumpfun" ? "border-orange-500/40 text-orange-400" : "border-blue-500/40 text-blue-400")}>
                    {t.source === "pumpfun" ? "pump" : "jup"}
                  </Badge>
                  <Badge variant="outline" className={cn("rounded-none border text-xs", t.status === "open" ? "border-primary/40 text-primary" : "border-border text-muted-foreground")}>
                    {t.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-muted-foreground">{usd(t.sizeUsd)}</span>
                  {t.pnlUsd !== null && t.pnlUsd !== undefined ? (
                    <span className={cn(t.pnlUsd >= 0 ? "profit" : "loss")}>
                      {t.pnlUsd >= 0 ? "+" : ""}{usd(t.pnlUsd)}
                    </span>
                  ) : <span className="text-muted-foreground">—</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
