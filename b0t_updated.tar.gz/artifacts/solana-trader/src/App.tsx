import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import TradePage from "@/pages/trade";
import PositionsPage from "@/pages/positions";
import TradesPage from "@/pages/trades";
import TokensPage from "@/pages/tokens";
import BotsPage from "@/pages/bots";
import AnalyticsPage from "@/pages/analytics";
import StrategyPage from "@/pages/strategy";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 20000 } },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/trade" component={TradePage} />
        <Route path="/positions" component={PositionsPage} />
        <Route path="/trades" component={TradesPage} />
        <Route path="/tokens" component={TokensPage} />
        <Route path="/bots" component={BotsPage} />
        <Route path="/analytics" component={AnalyticsPage} />
        <Route path="/strategy" component={StrategyPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
