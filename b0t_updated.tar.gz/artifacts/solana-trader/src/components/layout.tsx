import { Link, useLocation } from "wouter";
import { LayoutDashboard, TrendingUp, Briefcase, List, Layers, BarChart2, Settings, Bot } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/",          label: "dashboard",   icon: LayoutDashboard },
  { href: "/trade",     label: "new trade",   icon: TrendingUp },
  { href: "/positions", label: "positions",   icon: Briefcase },
  { href: "/trades",    label: "history",     icon: List },
  { href: "/tokens",    label: "tokens",      icon: Layers },
  { href: "/bots",      label: "bots",        icon: Bot },
  { href: "/analytics", label: "analytics",   icon: BarChart2 },
  { href: "/strategy",  label: "strategy",    icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [loc] = useLocation();

  return (
    <div className="flex h-screen w-full bg-background dark text-foreground overflow-hidden">
      {/* Sidebar */}
      <aside className="w-12 md:w-48 border-r border-border bg-sidebar flex flex-col shrink-0">
        <div className="h-11 flex items-center px-3 border-b border-border">
          <span className="font-mono font-bold text-primary tracking-widest hidden md:block text-sm">B0T</span>
          <span className="font-mono font-bold text-base text-primary md:hidden">B</span>
          <span className="hidden md:block ml-1.5 text-[10px] text-muted-foreground font-mono">/solana</span>
        </div>

        <nav className="flex-1 py-2 space-y-px px-1.5">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = loc === href;
            return (
              <Link key={href} href={href}>
                <div
                  data-testid={`nav-${label.replace(/\s+/g, '-')}`}
                  className={cn(
                    "flex items-center gap-2.5 px-2 py-1.5 text-xs cursor-pointer transition-colors rounded-sm",
                    active
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                  )}
                >
                  <Icon className="size-3.5 shrink-0" />
                  <span className="hidden md:block font-mono tracking-wide">{label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="px-3 py-2.5 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="size-1.5 rounded-full bg-green-500 shrink-0 animate-pulse" />
            <span className="hidden md:block font-mono text-[10px] text-muted-foreground">devnet · slip 10%</span>
          </div>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 h-full overflow-y-auto">
        <div className="max-w-5xl mx-auto p-4 md:p-7">
          {children}
        </div>
      </main>
    </div>
  );
}
