import { db } from "@workspace/db";
import { botsTable, botLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { runMonitorTick } from "./monitor.js";
import { runScalperTick } from "./scalper.js";
import { logger } from "../lib/logger.js";

const TICK_INTERVAL_MS = 30_000; // 30 seconds

let interval: ReturnType<typeof setInterval> | null = null;
let running = false;
let lastTickAt: Date | null = null;
let tickCount = 0;

export type EngineStatus = {
  running: boolean;
  lastTickAt: string | null;
  tickCount: number;
  liveMode: boolean;
  intervalMs: number;
};

export function getEngineStatus(): EngineStatus {
  return {
    running,
    lastTickAt: lastTickAt?.toISOString() ?? null,
    tickCount,
    liveMode: !!(process.env.SOLANA_RPC_URL && process.env.WALLET_PRIVATE_KEY),
    intervalMs: TICK_INTERVAL_MS,
  };
}

export function startEngine(): void {
  if (interval) return;
  running = true;
  logger.info({
    mode: process.env.SOLANA_RPC_URL ? "live" : "paper",
  }, "B0T engine starting");

  // First tick after 3s (let DB settle)
  setTimeout(() => tick(), 3000);
  interval = setInterval(() => tick(), TICK_INTERVAL_MS);
}

export function stopEngine(): void {
  if (interval) { clearInterval(interval); interval = null; }
  running = false;
  logger.info("B0T engine stopped");
}

async function tick(): Promise<void> {
  try {
    lastTickAt = new Date();
    tickCount++;

    // 1. Monitor all open positions — update prices, auto TP/SL
    const { updated, closed } = await runMonitorTick();
    if (closed > 0) {
      logger.info({ closed }, "Monitor auto-closed positions");
    }

    // 2. Run active bots
    const activeBots = await db.select().from(botsTable).where(eq(botsTable.active, true));
    for (const bot of activeBots) {
      try {
        if (bot.type === "scalper") {
          await runScalperTick(bot.id);
        }
        // 'compound_guard' logic is handled by monitor
        // 'dca' would have its own tick logic here
        await db.update(botsTable).set({ lastRunAt: new Date() }).where(eq(botsTable.id, bot.id));
      } catch (err) {
        logger.error({ err, botId: bot.id, botName: bot.name }, "Bot tick error");
        await db.insert(botLogsTable).values({
          botId: bot.id,
          level: "error",
          message: `Bot error: ${err instanceof Error ? err.message : String(err)}`,
          data: null,
        }).catch(() => {});
      }
    }
  } catch (err) {
    logger.error({ err }, "Engine tick fatal error");
  }
}
