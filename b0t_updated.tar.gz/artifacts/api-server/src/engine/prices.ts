const JUPITER_PRICE_URL = "https://api.jup.ag/price/v2";
const COINGECKO_URL = "https://api.coingecko.com/api/v3";
const DEX_SCREENER_URL = "https://api.dexscreener.com/latest/dex";
const SOL_MINT = "So11111111111111111111111111111111111111112";

// Cache prices for 20s to avoid hammering APIs
let priceCache: { prices: Record<string, number>; ts: number } = { prices: {}, ts: 0 };
let cgCache: { data: CoinGeckoToken[]; ts: number } = { data: [], ts: 0 };
let dexCache: { data: DexPair[]; ts: number } = { data: [], ts: 0 };

export type PriceSource = "jupiter" | "coingecko" | "dexscreener";

export interface CoinGeckoToken {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  market_cap: number;
  total_volume: number;
  price_change_percentage_24h: number;
  image: string;
}

export interface DexPair {
  chainId: string;
  dexId: string;
  pairAddress: string;
  baseToken: { address: string; name: string; symbol: string };
  quoteToken: { symbol: string };
  priceUsd: string;
  priceNative: string;
  volume: { h24: number };
  priceChange: { h1: number; h24: number };
  liquidity: { usd: number };
  fdv: number;
  txns?: { h24?: { buys: number; sells: number } };
}

export async function fetchPrices(mints: string[]): Promise<Record<string, number>> {
  if (!mints.length) return {};
  const allMints = Array.from(new Set([...mints.map(m => m.trim()), SOL_MINT]));
  try {
    const res = await fetch(`${JUPITER_PRICE_URL}?ids=${allMints.join(",")}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) throw new Error(`Jupiter price API ${res.status}`);
    const json = (await res.json()) as { data: Record<string, { price: number }> };
    const prices: Record<string, number> = {};
    for (const [mint, data] of Object.entries(json.data ?? {})) {
      if (data?.price) prices[mint] = data.price;
    }
    priceCache = { prices, ts: Date.now() };
    return prices;
  } catch (err) {
    if (priceCache.ts > 0) return priceCache.prices;
    throw err;
  }
}

export async function fetchCoinGeckoTrending(limit = 20): Promise<CoinGeckoToken[]> {
  const cacheAge = Date.now() - cgCache.ts;
  if (cgCache.data.length && cacheAge < 60_000) return cgCache.data.slice(0, limit);

  try {
    const res = await fetch(
      `${COINGECKO_URL}/coins/markets?vs_currency=usd&order=volume_desc&per_page=${Math.min(limit, 50)}&page=1&sparkline=false&price_change_percentage=24h`,
      { signal: AbortSignal.timeout(8000), headers: { Accept: "application/json" } }
    );
    if (!res.ok) throw new Error(`CoinGecko API ${res.status}`);
    const data = (await res.json()) as CoinGeckoToken[];
    cgCache = { data, ts: Date.now() };
    return data.slice(0, limit);
  } catch {
    return cgCache.data.slice(0, limit);
  }
}

export async function fetchDexScreenerPairs(query: string): Promise<DexPair[]> {
  const cacheAge = Date.now() - dexCache.ts;
  if (dexCache.data.length && cacheAge < 30_000 && !query) return dexCache.data;

  try {
    // Fetch trending Solana pairs
    const url = query
      ? `${DEX_SCREENER_URL}/search?q=${encodeURIComponent(query)}`
      : `${DEX_SCREENER_URL}/tokens/So11111111111111111111111111111111111111112`;

    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error(`DexScreener API ${res.status}`);
    const json = (await res.json()) as { pairs: DexPair[] };
    const pairs = (json.pairs ?? [])
      .filter((p: DexPair) => p.chainId === "solana" && parseFloat(p.priceUsd) > 0)
      .slice(0, 20);
    if (!query) dexCache = { data: pairs, ts: Date.now() };
    return pairs;
  } catch {
    return dexCache.data;
  }
}

export function getSolPrice(): number {
  return priceCache.prices[SOL_MINT] ?? 150;
}
