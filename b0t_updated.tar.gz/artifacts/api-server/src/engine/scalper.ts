import { db } from "@workspace/db";
import { botsTable, botLogsTable, positionsTable, tradesTable, strategyTable } from "@workspace/db";
import { eq, count, desc } from "drizzle-orm";
import { fetchPrices } from "./prices.js";
import { executeBuy } from "./jupiter.js";
import { logger } from "../lib/logger.js";

// Simulated PumpFun token candidates for scalper bot
// In production, replace with real PumpFun trending API
const PUMP_CANDIDATES = [
  { mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", symbol: "BONK", name: "Bonk" },
  { mint: "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr", symbol: "POPCAT", name: "Popcat" },
  { mint: "MEW1gQWJ3nEXg2qgERiKu7FAFj79PHvQVREQUzScPP5", symbol: "MEW", name: "cat in a dogs world" },
];

export async function runScalperTick(botId: number): Promise<void> {
  const [bot] = await db.select().from(botsTable).where(eq(botsTable.id, botId)).limit(1);
  if (!bot || !bot.active) return;

  const [strategy] = await db.select().from(strategyTable).orderBy(desc(strategyTable.id)).limit(1);
  if (!strategy) return;

  // Check position count limit
  const [{ count: openCount }] = await db.select({ count: count() }).from(positionsTable);
  if (Number(openCount) >= strategy.maxOpenPositions) {
    await log(botId, "info", `Max open positions (${strategy.maxOpenPositions}) reached — skipping scan`);
    return;
  }

  // Fetch prices for candidates
  const mints = PUMP_CANDIDATES.map(t => t.mint);
  let prices: Record<string, number>;
  try {
    prices = await fetchPrices(mints);
  } catch {
    await log(botId, "warn", "Failed to fetch token prices — skipping scalper tick");
    return;
  }

  // Simple momentum signal: look for tokens not already in a position
  const existingPositions = await db.select({ mint: positionsTable.tokenMint }).from(positionsTable);
  const existingMints = new Set(existingPositions.map(p => p.mint));

  for (const token of PUMP_CANDIDATES) {
    if (existingMints.has(token.mint)) continue;

    const price = prices[token.mint];
    if (!price) continue;

    // Simulate momentum signal: random chance in paper mode (replace with real signal logic)
    const momentum = Math.random(); // In production: volume-weighted momentum score
    if (momentum < 0.8) continue; // Only 20% chance per tick for demonstration

    // Calculate position size respecting max% rule
    const portfolioValue = 500; // In production: fetch from portfolio
    const maxSize = (strategy.maxPositionPct / 100) * portfolioValue;
    const sizeUsd = Math.min(maxSize, 50); // Default $50 or max%, whichever is smaller

    const slippageBps = 1000; // 10% slippage — hardcoded

    await log(botId, "trade", `Scalper signal: ${token.symbol} @ $${price.toFixed(6)} — entering $${sizeUsd} position`);

    // Execute (paper or live)
    const result = await executeBuy({
      tokenMint: token.mint,
      currentTokenPrice: price,
      amountUsd: sizeUsd,
      slippageBps,
    });

    // Record trade + position
    const fillPrice = result.fillPrice;
    const [trade] = await db.insert(tradesTable).values({
      tokenMint: token.mint,
      tokenSymbol: token.symbol,
      tokenName: token.name,
      side: "buy",
      entryPrice: fillPrice,
      sizeUsd,
      sizeSol: sizeUsd / 150,
      slippagePct: strategy.slippagePct,
      takeProfitPct: strategy.defaultTakeProfitPct,
      stopLossPct: strategy.defaultStopLossPct,
      status: "open",
      thesis: `[BOT:scalper] Momentum signal — auto-entry`,
      source: "pumpfun",
      txHash: result.txHash,
    }).returning();

    await db.insert(positionsTable).values({
      tokenMint: token.mint,
      tokenSymbol: token.symbol,
      tokenName: token.name,
      entryPrice: fillPrice,
      currentPrice: fillPrice,
      sizeUsd,
      unrealizedPnl: 0,
      unrealizedPnlPct: 0,
      takeProfitPct: strategy.defaultTakeProfitPct,
      stopLossPct: strategy.defaultStopLossPct,
      source: "pumpfun",
      thesis: `[BOT:scalper] Momentum signal`,
    });

    await db.update(botsTable)
      .set({ totalTrades: bot.totalTrades + 1, lastRunAt: new Date() })
      .where(eq(botsTable.id, botId));

    await log(botId, "info", `${result.paperMode ? "[PAPER]" : "[LIVE]"} Opened ${token.symbol} @ $${fillPrice.toFixed(6)} | TP +${strategy.defaultTakeProfitPct}% | SL -${strategy.defaultStopLossPct}%`);
    break; // One trade per tick
  }
}

async function log(botId: number, level: string, message: string, data?: Record<string, unknown>) {
  try {
    await db.insert(botLogsTable).values({ botId, level, message, data: data ?? null });
  } catch { /* non-critical */ }
}
