import { getSolPrice } from "./prices.js";
import { logger } from "../lib/logger.js";

const QUOTE_URL = "https://quote-api.jup.ag/v6/quote";
const SWAP_URL  = "https://quote-api.jup.ag/v6/swap";
const SOL_MINT  = "So11111111111111111111111111111111111111112";
const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";

export type SwapResult = {
  txHash: string | null;
  fillPrice: number;
  paperMode: boolean;
  error?: string;
};

/**
 * Execute a buy swap: SOL → token.
 * Falls back to paper-trade mode if SOLANA_RPC_URL / WALLET_PRIVATE_KEY are not set.
 */
export async function executeBuy(opts: {
  tokenMint: string;
  currentTokenPrice: number;
  amountUsd: number;
  slippageBps: number;
}): Promise<SwapResult> {
  const { tokenMint, currentTokenPrice, amountUsd, slippageBps } = opts;
  const rpcUrl     = process.env.SOLANA_RPC_URL;
  const privateKey = process.env.WALLET_PRIVATE_KEY;

  if (!rpcUrl || !privateKey) {
    return { txHash: null, fillPrice: currentTokenPrice, paperMode: true };
  }

  try {
    const solPrice  = getSolPrice();
    const solAmount = amountUsd / solPrice;
    const lamports  = Math.round(solAmount * 1e9);

    // 1. Get quote
    const quoteUrl = `${QUOTE_URL}?inputMint=${SOL_MINT}&outputMint=${tokenMint}&amount=${lamports}&slippageBps=${slippageBps}`;
    const quoteRes = await fetch(quoteUrl, { signal: AbortSignal.timeout(10000) });
    if (!quoteRes.ok) throw new Error(`Quote API error ${quoteRes.status}`);
    const quoteResponse = await quoteRes.json();

    // 2. Get swap transaction
    const swapRes = await fetch(SWAP_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: AbortSignal.timeout(10000),
      body: JSON.stringify({
        quoteResponse,
        userPublicKey: await getPublicKey(privateKey),
        wrapAndUnwrapSol: true,
        dynamicComputeUnitLimit: true,
        prioritizationFeeLamports: "auto",
      }),
    });
    if (!swapRes.ok) throw new Error(`Swap API error ${swapRes.status}`);
    const { swapTransaction } = (await swapRes.json()) as { swapTransaction: string };

    // 3. Sign and submit
    const txHash = await signAndSend(swapTransaction, privateKey, rpcUrl);
    logger.info({ txHash, tokenMint, amountUsd }, "Swap executed");
    return { txHash, fillPrice: currentTokenPrice, paperMode: false };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err: msg, tokenMint }, "Swap execution failed — falling back to paper mode");
    return { txHash: null, fillPrice: currentTokenPrice, paperMode: true, error: msg };
  }
}

async function getPublicKey(privateKeyB58: string): Promise<string> {
  const { Keypair } = await import("@solana/web3.js");
  const bs58 = (await import("bs58")).default;
  const kp = Keypair.fromSecretKey(bs58.decode(privateKeyB58));
  return kp.publicKey.toBase58();
}

async function signAndSend(swapTxB64: string, privateKeyB58: string, rpcUrl: string): Promise<string> {
  const { Connection, VersionedTransaction, Keypair } = await import("@solana/web3.js");
  const bs58 = (await import("bs58")).default;

  const connection = new Connection(rpcUrl, "confirmed");
  const kp = Keypair.fromSecretKey(bs58.decode(privateKeyB58));
  const txBuf = Buffer.from(swapTxB64, "base64");
  const tx = VersionedTransaction.deserialize(txBuf);
  tx.sign([kp]);
  const sig = await connection.sendRawTransaction(tx.serialize(), {
    skipPreflight: false,
    maxRetries: 2,
  });
  await connection.confirmTransaction(sig, "confirmed");
  return sig;
}
