import { db } from "@workspace/db";
import { positionsTable, tradesTable, strategyTable, botLogsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { fetchPrices } from "./prices.js";
import { logger } from "../lib/logger.js";

export type CloseReason = "take_profit" | "stop_loss" | "manual";

export async function closePosition(
  posId: number,
  exitPrice: number,
  reason: CloseReason,
): Promise<void> {
  const [pos] = await db.select().from(positionsTable).where(eq(positionsTable.id, posId)).limit(1);
  if (!pos) return;

  const pnlPct = ((exitPrice - pos.entryPrice) / pos.entryPrice) * 100;
  const pnlUsd = (pnlPct / 100) * pos.sizeUsd;

  await db.update(tradesTable)
    .set({ status: "closed", exitPrice, pnlUsd, pnlPct, closedAt: new Date() })
    .where(eq(tradesTable.tokenMint, pos.tokenMint));

  await db.delete(positionsTable).where(eq(positionsTable.id, posId));

  await db.insert(botLogsTable).values({
    botId: null,
    level: "trade",
    message: `[${reason.toUpperCase()}] Closed ${pos.tokenSymbol} @ $${exitPrice.toFixed(6)} | PnL: ${pnlPct >= 0 ? "+" : ""}${pnlPct.toFixed(2)}% ($${pnlUsd >= 0 ? "+" : ""}${pnlUsd.toFixed(2)})`,
    data: { positionId: posId, tokenMint: pos.tokenMint, tokenSymbol: pos.tokenSymbol, exitPrice, pnlPct, pnlUsd, reason },
  });

  logger.info({ tokenSymbol: pos.tokenSymbol, pnlPct, reason }, "Position auto-closed by monitor");
}

export async function runMonitorTick(): Promise<{ updated: number; closed: number }> {
  const positions = await db.select().from(positionsTable);
  if (!positions.length) return { updated: 0, closed: 0 };

  const mints = Array.from(new Set(positions.map(p => p.tokenMint)));
  let prices: Record<string, number>;
  try {
    prices = await fetchPrices(mints);
  } catch {
    logger.warn("Price fetch failed — skipping monitor tick");
    return { updated: 0, closed: 0 };
  }

  const [strategy] = await db.select().from(strategyTable).orderBy(desc(strategyTable.id)).limit(1);
  let updated = 0;
  let closed = 0;

  for (const pos of positions) {
    const price = prices[pos.tokenMint];
    if (price === undefined || price <= 0) continue;

    const pnlPct = ((price - pos.entryPrice) / pos.entryPrice) * 100;
    const pnlUsd = (pnlPct / 100) * pos.sizeUsd;

    // Update live price + P&L
    await db.update(positionsTable)
      .set({ currentPrice: price, unrealizedPnl: pnlUsd, unrealizedPnlPct: pnlPct })
      .where(eq(positionsTable.id, pos.id));
    updated++;

    // TP check
    if (strategy?.autoTakeProfit && pnlPct >= pos.takeProfitPct) {
      await closePosition(pos.id, price, "take_profit");
      closed++;
      continue;
    }

    // SL check
    if (strategy?.autoStopLoss && pnlPct <= -Math.abs(pos.stopLossPct)) {
      await closePosition(pos.id, price, "stop_loss");
      closed++;
    }
  }

  if (updated > 0) {
    logger.debug({ updated, closed }, "Monitor tick complete");
  }

  return { updated, closed };
}
