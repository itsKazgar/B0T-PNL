import { Router } from "express";
import { db } from "@workspace/db";
import { strategyTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function ensureDefaultStrategy() {
  const existing = await db.select().from(strategyTable).limit(1);
  if (existing.length === 0) {
    const [created] = await db.insert(strategyTable).values({
      slippagePct: 10,
      defaultTakeProfitPct: 30,
      defaultStopLossPct: 15,
      maxPositionPct: 20,
      maxOpenPositions: 5,
      compoundFloorPct: 50,
      autoTakeProfit: true,
      autoStopLoss: true,
    }).returning();
    return created;
  }
  return existing[0];
}

router.get("/strategy", async (_req, res) => {
  try {
    const strategy = await ensureDefaultStrategy();
    res.json(serializeStrategy(strategy));
  } catch {
    res.status(500).json({ error: "Failed to get strategy" });
  }
});

router.put("/strategy", async (req, res) => {
  try {
    const strategy = await ensureDefaultStrategy();
    const body = req.body;
    const update: Record<string, unknown> = { updatedAt: new Date() };
    if (body.slippagePct !== undefined) update.slippagePct = body.slippagePct;
    if (body.defaultTakeProfitPct !== undefined) update.defaultTakeProfitPct = body.defaultTakeProfitPct;
    if (body.defaultStopLossPct !== undefined) update.defaultStopLossPct = body.defaultStopLossPct;
    if (body.maxPositionPct !== undefined) update.maxPositionPct = body.maxPositionPct;
    if (body.maxOpenPositions !== undefined) update.maxOpenPositions = body.maxOpenPositions;
    if (body.compoundFloorPct !== undefined) update.compoundFloorPct = body.compoundFloorPct;
    if (body.autoTakeProfit !== undefined) update.autoTakeProfit = body.autoTakeProfit;
    if (body.autoStopLoss !== undefined) update.autoStopLoss = body.autoStopLoss;

    const [updated] = await db.update(strategyTable)
      .set(update)
      .where(eq(strategyTable.id, strategy.id))
      .returning();
    res.json(serializeStrategy(updated));
  } catch {
    res.status(500).json({ error: "Failed to update strategy" });
  }
});

function serializeStrategy(s: typeof strategyTable.$inferSelect) {
  return {
    ...s,
    updatedAt: s.updatedAt.toISOString(),
  };
}

export default router;
