import { Router } from "express";
import { fetchCoinGeckoTrending, fetchDexScreenerPairs } from "../engine/prices.js";

const router = Router();

const JUP_TOKENS = [
  { mint: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN", symbol: "JUP", name: "Jupiter", logoUri: null, priceUsd: 0.82, volume24h: 48200000, marketCap: 1080000000, change24h: 3.4 },
  { mint: "So11111111111111111111111111111111111111112", symbol: "SOL", name: "Solana", logoUri: null, priceUsd: 185.20, volume24h: 2100000000, marketCap: 86000000000, change24h: 1.8 },
  { mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", symbol: "USDC", name: "USD Coin", logoUri: null, priceUsd: 1.0, volume24h: 890000000, marketCap: 45000000000, change24h: 0.01 },
  { mint: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", symbol: "BONK", name: "Bonk", logoUri: null, priceUsd: 0.0000248, volume24h: 95000000, marketCap: 1600000000, change24h: 8.2 },
  { mint: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R", symbol: "RAY", name: "Raydium", logoUri: null, priceUsd: 2.84, volume24h: 67000000, marketCap: 620000000, change24h: -1.4 },
  { mint: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE", symbol: "ORCA", name: "Orca", logoUri: null, priceUsd: 3.21, volume24h: 15000000, marketCap: 178000000, change24h: 4.1 },
  { mint: "HZ1JovNiVvGrCNiiYWY1CzvYhV72zVyiMQm1LdZs5KWc", symbol: "PYTH", name: "Pyth Network", logoUri: null, priceUsd: 0.38, volume24h: 22000000, marketCap: 530000000, change24h: -0.7 },
  { mint: "jtojtomepa8b1dtRYkSnz4RRzGGCKnmvYWYBJQqHMH5", symbol: "JTO", name: "Jito", logoUri: null, priceUsd: 2.74, volume24h: 78000000, marketCap: 720000000, change24h: 2.8 },
  { mint: "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So", symbol: "mSOL", name: "Marinade staked SOL", logoUri: null, priceUsd: 204.80, volume24h: 45000000, marketCap: 920000000, change24h: 1.9 },
  { mint: "nosXBVoaCTtYdLvKY6Csb4AC8JCdQKKAaWYtx2ZMoo7", symbol: "NOS", name: "Nosana", logoUri: null, priceUsd: 1.42, volume24h: 8900000, marketCap: 61000000, change24h: 12.3 },
];

const PUMPFUN_TOKENS = [
  { mint: "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr", symbol: "POPCAT", name: "Popcat", imageUri: null, priceUsd: 0.884, marketCap: 884000000, volume24h: 210000000, bondingCurvePct: 100, change1h: 4.2, createdAt: new Date(Date.now() - 86400000 * 120).toISOString(), description: "The internet's favorite cat, now on Solana." },
  { mint: "A3eME5CetyZPBoWbRUwY3tSe25S6tb18ba9ZPbWk9eFJ", symbol: "PNUT", name: "Peanut the Squirrel", imageUri: null, priceUsd: 0.644, marketCap: 644000000, volume24h: 185000000, bondingCurvePct: 100, change1h: -1.8, createdAt: new Date(Date.now() - 86400000 * 90).toISOString(), description: "Peanut, the beloved squirrel." },
  { mint: "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo", symbol: "FWOG", name: "FWOG", imageUri: null, priceUsd: 0.1182, marketCap: 118200000, volume24h: 45000000, bondingCurvePct: 100, change1h: 7.3, createdAt: new Date(Date.now() - 86400000 * 60).toISOString(), description: "Just a fwog, vibing." },
  { mint: "ED5nyyWEzpPPiWimP8vYm7sD7TD3LAt3Q3gRTWHzc8yy", symbol: "MOODENG", name: "Moo Deng", imageUri: null, priceUsd: 0.2034, marketCap: 203400000, volume24h: 92000000, bondingCurvePct: 100, change1h: 2.1, createdAt: new Date(Date.now() - 86400000 * 45).toISOString(), description: "Thailand's baby hippo, now a meme." },
  { mint: "Df6yfrKC8kZE3KNkrHERKzAetSxbrWeniQfyJY4Jpump", symbol: "CHILLGUY", name: "Just a Chill Guy", imageUri: null, priceUsd: 0.3851, marketCap: 385100000, volume24h: 140000000, bondingCurvePct: 100, change1h: 11.4, createdAt: new Date(Date.now() - 86400000 * 30).toISOString(), description: "Just a chill guy." },
  { mint: "9BB6NFEcjBCtnNLFko2FqVQBq8HHM13kCyYcdQbgpump", symbol: "Fartcoin", name: "Fartcoin", imageUri: null, priceUsd: 1.04, marketCap: 1040000000, volume24h: 320000000, bondingCurvePct: 100, change1h: 5.8, createdAt: new Date(Date.now() - 86400000 * 15).toISOString(), description: "A gas-powered currency." },
  { mint: "8x5VqbHA8D7NkD52uNuS5nnt3PwA8pLD34ymskeSo2Wn", symbol: "GOAT", name: "Goatseus Maximus", imageUri: null, priceUsd: 0.672, marketCap: 672000000, volume24h: 188000000, bondingCurvePct: 100, change1h: -0.4, createdAt: new Date(Date.now() - 86400000 * 25).toISOString(), description: "The greatest of all time." },
  { mint: "HeLp6NuQkmYB4pYWo2zYs22mESHXPQYzXbB8n4V98jwC", symbol: "ai16z", name: "ai16z", imageUri: null, priceUsd: 1.28, marketCap: 1280000000, volume24h: 450000000, bondingCurvePct: 100, change1h: 8.9, createdAt: new Date(Date.now() - 86400000 * 50).toISOString(), description: "The AI venture capital DAO." },
  { mint: "5mbK36SZ7J19An8jFochhQS4of8g6BwUjbeCSxBSoWdp", symbol: "MEOW", name: "Cat in a Dog World", imageUri: null, priceUsd: 0.00892, marketCap: 89200000, volume24h: 28000000, bondingCurvePct: 78, change1h: 15.2, createdAt: new Date(Date.now() - 86400000 * 5).toISOString(), description: "A cat surviving in a dog world." },
  { mint: "3psH1Mj1f7yUfaVrLZiMo2Qs2p1oJ8KWq5UtJLx2P4X", symbol: "KEKIUS", name: "Kekius Maximus", imageUri: null, priceUsd: 0.0412, marketCap: 41200000, volume24h: 18000000, bondingCurvePct: 62, change1h: 22.1, createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), description: "Based and kek-pilled." },
];

// Jupiter tokens
router.get("/tokens/jupiter", async (req, res) => {
  try {
    const q = ((req.query.q as string) || "").toLowerCase();
    const limit = Math.min(Number(req.query.limit) || 20, 50);
    let results = JUP_TOKENS;
    if (q) results = results.filter(t => t.symbol.toLowerCase().includes(q) || t.name.toLowerCase().includes(q));
    res.json(results.slice(0, limit).map(t => ({
      ...t,
      priceUsd: t.priceUsd * (1 + (Math.random() - 0.5) * 0.01),
    })));
  } catch {
    res.status(500).json({ error: "Failed to list Jupiter tokens" });
  }
});

// PumpFun tokens
router.get("/tokens/pumpfun", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 20, 50);
    const sort = (req.query.sort as string) || "trending";
    let results = [...PUMPFUN_TOKENS];
    if (sort === "volume") results.sort((a, b) => b.volume24h - a.volume24h);
    else if (sort === "new") results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    else results.sort((a, b) => b.marketCap - a.marketCap);
    res.json(results.slice(0, limit).map(t => ({
      ...t,
      priceUsd: t.priceUsd * (1 + (Math.random() - 0.5) * 0.02),
      change1h: t.change1h !== null ? t.change1h + (Math.random() - 0.5) * 0.5 : null,
    })));
  } catch {
    res.status(500).json({ error: "Failed to list PumpFun tokens" });
  }
});

// CoinGecko — live market data
router.get("/tokens/coingecko", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 20, 50);
    const data = await fetchCoinGeckoTrending(limit);
    res.json(data);
  } catch {
    res.status(500).json({ error: "Failed to fetch CoinGecko data" });
  }
});

// DEX Screener — live Solana pairs
router.get("/tokens/dexscreener", async (req, res) => {
  try {
    const q = (req.query.q as string) || "";
    const pairs = await fetchDexScreenerPairs(q);
    res.json(pairs);
  } catch {
    res.status(500).json({ error: "Failed to fetch DEX Screener data" });
  }
});

// Price for a single token
router.get("/tokens/:mint/price", async (req, res) => {
  try {
    const { mint } = req.params;
    const allTokens = [...JUP_TOKENS, ...PUMPFUN_TOKENS];
    const token = allTokens.find(t => t.mint === mint);
    const priceUsd = token ? token.priceUsd * (1 + (Math.random() - 0.5) * 0.02) : Math.random() * 0.01;
    res.json({ mint, priceUsd, priceNative: priceUsd / 185.2, updatedAt: new Date().toISOString() });
  } catch {
    res.status(500).json({ error: "Failed to get token price" });
  }
});

export default router;
