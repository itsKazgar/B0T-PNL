import { Router } from "express";
import { db } from "@workspace/db";
import { tradesTable, positionsTable, strategyTable } from "@workspace/db";
import { eq, desc, and, sql } from "drizzle-orm";

const router = Router();

router.get("/trades", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 50, 200);
    const offset = Number(req.query.offset) || 0;
    const status = req.query.status as string | undefined;

    let query = db.select().from(tradesTable).$dynamic();
    if (status && ["open", "closed", "cancelled"].includes(status)) {
      query = query.where(eq(tradesTable.status, status as "open" | "closed" | "cancelled"));
    }
    const trades = await query.orderBy(desc(tradesTable.createdAt)).limit(limit).offset(offset);
    res.json(trades.map(serializeTrade));
  } catch {
    res.status(500).json({ error: "Failed to list trades" });
  }
});

router.get("/trades/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [trade] = await db.select().from(tradesTable).where(eq(tradesTable.id, id)).limit(1);
    if (!trade) return res.status(404).json({ error: "Trade not found" });
    res.json(serializeTrade(trade));
  } catch {
    res.status(500).json({ error: "Failed to get trade" });
  }
});

router.post("/trades", async (req, res) => {
  try {
    const body = req.body;
    const [strategy] = await db.select().from(strategyTable).limit(1);
    const slippage = body.slippagePct ?? strategy?.slippagePct ?? 10;
    const tp = body.takeProfitPct ?? strategy?.defaultTakeProfitPct ?? 30;
    const sl = body.stopLossPct ?? strategy?.defaultStopLossPct ?? 15;
    const entryPrice = body.entryPrice ?? (Math.random() * 0.5 + 0.001);
    const solPrice = 185;
    const sizeSol = body.sizeUsd / solPrice;

    const [trade] = await db.insert(tradesTable).values({
      tokenMint: body.tokenMint,
      tokenSymbol: body.tokenSymbol,
      tokenName: body.tokenName,
      side: body.side ?? "buy",
      entryPrice,
      sizeUsd: body.sizeUsd,
      sizeSol,
      slippagePct: slippage,
      takeProfitPct: tp,
      stopLossPct: sl,
      status: "open",
      thesis: body.thesis,
      source: body.source,
    }).returning();

    // Create an open position
    await db.insert(positionsTable).values({
      tokenMint: body.tokenMint,
      tokenSymbol: body.tokenSymbol,
      tokenName: body.tokenName,
      entryPrice,
      currentPrice: entryPrice,
      sizeUsd: body.sizeUsd,
      unrealizedPnl: 0,
      unrealizedPnlPct: 0,
      takeProfitPct: tp,
      stopLossPct: sl,
      source: body.source,
      thesis: body.thesis,
    });

    res.status(201).json(serializeTrade(trade));
  } catch {
    res.status(500).json({ error: "Failed to create trade" });
  }
});

function serializeTrade(t: typeof tradesTable.$inferSelect) {
  return {
    ...t,
    closedAt: t.closedAt ? t.closedAt.toISOString() : null,
    createdAt: t.createdAt.toISOString(),
  };
}

export default router;
