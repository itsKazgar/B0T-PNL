import { Router } from "express";
import { db } from "@workspace/db";
import { positionsTable, tradesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/positions", async (_req, res) => {
  try {
    const positions = await db.select().from(positionsTable).orderBy(desc(positionsTable.openedAt));
    res.json(positions.map(serializePosition));
  } catch {
    res.status(500).json({ error: "Failed to list positions" });
  }
});

router.get("/positions/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [position] = await db.select().from(positionsTable).where(eq(positionsTable.id, id)).limit(1);
    if (!position) return res.status(404).json({ error: "Position not found" });
    res.json(serializePosition(position));
  } catch {
    res.status(500).json({ error: "Failed to get position" });
  }
});

router.patch("/positions/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { takeProfitPct, stopLossPct, currentPrice } = req.body;
    const update: Record<string, unknown> = {};
    if (takeProfitPct !== undefined) update.takeProfitPct = takeProfitPct;
    if (stopLossPct !== undefined) update.stopLossPct = stopLossPct;
    if (currentPrice !== undefined) {
      update.currentPrice = currentPrice;
      const [pos] = await db.select().from(positionsTable).where(eq(positionsTable.id, id)).limit(1);
      if (pos) {
        const pnlPct = ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100;
        update.unrealizedPnlPct = pnlPct;
        update.unrealizedPnl = (pnlPct / 100) * pos.sizeUsd;
      }
    }
    const [updated] = await db.update(positionsTable).set(update).where(eq(positionsTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Position not found" });
    res.json(serializePosition(updated));
  } catch {
    res.status(500).json({ error: "Failed to update position" });
  }
});

router.post("/positions/:id/close", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [position] = await db.select().from(positionsTable).where(eq(positionsTable.id, id)).limit(1);
    if (!position) return res.status(404).json({ error: "Position not found" });

    const exitPrice = position.currentPrice;
    const pnlPct = ((exitPrice - position.entryPrice) / position.entryPrice) * 100;
    const pnlUsd = (pnlPct / 100) * position.sizeUsd;

    // Close the trade in the trades table
    await db.update(tradesTable)
      .set({
        status: "closed",
        exitPrice,
        pnlUsd,
        pnlPct,
        closedAt: new Date(),
      })
      .where(eq(tradesTable.tokenMint, position.tokenMint));

    const [deleted] = await db.delete(positionsTable).where(eq(positionsTable.id, id)).returning();
    res.json(serializePosition({ ...deleted, unrealizedPnl: pnlUsd, unrealizedPnlPct: pnlPct }));
  } catch {
    res.status(500).json({ error: "Failed to close position" });
  }
});

function serializePosition(p: typeof positionsTable.$inferSelect) {
  return {
    ...p,
    openedAt: p.openedAt.toISOString(),
  };
}

export default router;
