import { Router, type IRouter } from "express";
import healthRouter from "./health";
import portfolioRouter from "./portfolio";
import tradesRouter from "./trades";
import positionsRouter from "./positions";
import tokensRouter from "./tokens";
import strategyRouter from "./strategy";
import analyticsRouter from "./analytics";
import botsRouter from "./bots";

const router: IRouter = Router();

router.use(healthRouter);
router.use(portfolioRouter);
router.use(tradesRouter);
router.use(positionsRouter);
router.use(tokensRouter);
router.use(strategyRouter);
router.use(analyticsRouter);
router.use(botsRouter);

export default router;
