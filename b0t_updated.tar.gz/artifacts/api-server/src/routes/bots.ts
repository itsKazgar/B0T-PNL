import { Router } from "express";
import { db } from "@workspace/db";
import { botsTable, botLogsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { getEngineStatus } from "../engine/runner.js";

const router = Router();

// List all bots
router.get("/bots", async (_req, res) => {
  try {
    const bots = await db.select().from(botsTable).orderBy(desc(botsTable.createdAt));
    res.json(bots.map(serializeBot));
  } catch {
    res.status(500).json({ error: "Failed to list bots" });
  }
});

// Create a bot
router.post("/bots", async (req, res) => {
  try {
    const { name, type, source, config } = req.body;
    if (!name || !type || !source) return res.status(400).json({ error: "name, type, source required" });
    const [bot] = await db.insert(botsTable).values({ name, type, source, config: config ?? {} }).returning();
    res.status(201).json(serializeBot(bot));
  } catch {
    res.status(500).json({ error: "Failed to create bot" });
  }
});

// Get single bot
router.get("/bots/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [bot] = await db.select().from(botsTable).where(eq(botsTable.id, id)).limit(1);
    if (!bot) return res.status(404).json({ error: "Bot not found" });
    res.json(serializeBot(bot));
  } catch {
    res.status(500).json({ error: "Failed to get bot" });
  }
});

// Update bot settings
router.patch("/bots/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, config } = req.body;
    const update: Record<string, unknown> = {};
    if (name !== undefined) update.name = name;
    if (config !== undefined) update.config = config;
    const [bot] = await db.update(botsTable).set(update).where(eq(botsTable.id, id)).returning();
    if (!bot) return res.status(404).json({ error: "Bot not found" });
    res.json(serializeBot(bot));
  } catch {
    res.status(500).json({ error: "Failed to update bot" });
  }
});

// Start a bot
router.post("/bots/:id/start", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [bot] = await db.update(botsTable)
      .set({ active: true })
      .where(eq(botsTable.id, id))
      .returning();
    if (!bot) return res.status(404).json({ error: "Bot not found" });
    await db.insert(botLogsTable).values({ botId: id, level: "info", message: `Bot "${bot.name}" started`, data: null });
    res.json(serializeBot(bot));
  } catch {
    res.status(500).json({ error: "Failed to start bot" });
  }
});

// Stop a bot
router.post("/bots/:id/stop", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [bot] = await db.update(botsTable)
      .set({ active: false })
      .where(eq(botsTable.id, id))
      .returning();
    if (!bot) return res.status(404).json({ error: "Bot not found" });
    await db.insert(botLogsTable).values({ botId: id, level: "info", message: `Bot "${bot.name}" stopped`, data: null });
    res.json(serializeBot(bot));
  } catch {
    res.status(500).json({ error: "Failed to stop bot" });
  }
});

// Delete a bot
router.delete("/bots/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(botsTable).where(eq(botsTable.id, id));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "Failed to delete bot" });
  }
});

// Get bot logs (most recent first)
router.get("/bots/logs/recent", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit ?? 50), 200);
    const logs = await db.select().from(botLogsTable).orderBy(desc(botLogsTable.createdAt)).limit(limit);
    res.json(logs.map(l => ({ ...l, createdAt: l.createdAt.toISOString() })));
  } catch {
    res.status(500).json({ error: "Failed to get logs" });
  }
});

// Engine status
router.get("/engine/status", (_req, res) => {
  res.json(getEngineStatus());
});

function serializeBot(b: typeof botsTable.$inferSelect) {
  return {
    ...b,
    lastRunAt: b.lastRunAt?.toISOString() ?? null,
    createdAt: b.createdAt.toISOString(),
  };
}

export default router;
