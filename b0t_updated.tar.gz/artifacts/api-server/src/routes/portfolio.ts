import { Router } from "express";
import { db } from "@workspace/db";
import { positionsTable, tradesTable, strategyTable } from "@workspace/db";
import { eq, sum, count } from "drizzle-orm";

const router = Router();

router.get("/portfolio", async (_req, res) => {
  try {
    const [positions, closedTrades, strategy] = await Promise.all([
      db.select().from(positionsTable),
      db.select().from(tradesTable).where(eq(tradesTable.status, "closed")),
      db.select().from(strategyTable).limit(1),
    ]);

    const totalTrades = await db.select({ count: count() }).from(tradesTable);

    const totalValueUsd = positions.reduce((sum, p) => sum + p.sizeUsd, 0) + 500;
    const unrealizedPnl = positions.reduce((sum, p) => sum + (p.unrealizedPnl || 0), 0);
    const realizedPnl = closedTrades.reduce((sum, t) => sum + (t.pnlUsd || 0), 0);
    const allocatedUsd = positions.reduce((sum, p) => sum + p.sizeUsd, 0);
    const floorPct = strategy[0]?.compoundFloorPct ?? 50;
    const compoundFloorUsd = totalValueUsd * (floorPct / 100);
    const solPrice = 185;
    const solBalance = (totalValueUsd - allocatedUsd) / solPrice;

    res.json({
      solBalance: Math.max(0, solBalance),
      totalValueUsd,
      allocatedUsd,
      reservedUsd: compoundFloorUsd,
      compoundFloorUsd,
      openPositions: positions.length,
      totalTrades: totalTrades[0]?.count ?? 0,
      unrealizedPnl,
      realizedPnl,
      walletAddress: null,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to get portfolio" });
  }
});

export default router;
