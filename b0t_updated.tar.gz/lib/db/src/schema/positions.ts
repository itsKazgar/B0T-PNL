import { pgTable, serial, text, real, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const positionSourceEnum = pgEnum("position_source", ["jupiter", "pumpfun"]);

export const positionsTable = pgTable("positions", {
  id: serial("id").primaryKey(),
  tokenMint: text("token_mint").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  tokenName: text("token_name").notNull(),
  entryPrice: real("entry_price").notNull(),
  currentPrice: real("current_price").notNull(),
  sizeUsd: real("size_usd").notNull(),
  unrealizedPnl: real("unrealized_pnl").notNull().default(0),
  unrealizedPnlPct: real("unrealized_pnl_pct").notNull().default(0),
  takeProfitPct: real("take_profit_pct").notNull().default(30),
  stopLossPct: real("stop_loss_pct").notNull().default(15),
  source: positionSourceEnum("source").notNull(),
  thesis: text("thesis"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
});

export const insertPositionSchema = createInsertSchema(positionsTable).omit({ id: true, openedAt: true });
export type InsertPosition = z.infer<typeof insertPositionSchema>;
export type Position = typeof positionsTable.$inferSelect;
