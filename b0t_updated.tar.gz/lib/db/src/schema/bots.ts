import { pgTable, serial, text, boolean, timestamp, json, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const botsTable = pgTable("bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'scalper' | 'dca' | 'compound_guard'
  source: text("source").notNull(), // 'jupiter' | 'pumpfun' | 'both'
  active: boolean("active").notNull().default(false),
  config: json("config").$type<Record<string, unknown>>().notNull().default({}),
  totalTrades: integer("total_trades").notNull().default(0),
  lastRunAt: timestamp("last_run_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const botLogsTable = pgTable("bot_logs", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").references(() => botsTable.id),
  level: text("level").notNull(), // 'info' | 'warn' | 'error' | 'trade'
  message: text("message").notNull(),
  data: json("data").$type<Record<string, unknown> | null>().default(null),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBotSchema = createInsertSchema(botsTable).omit({ id: true, createdAt: true, totalTrades: true, lastRunAt: true });
export type InsertBot = z.infer<typeof insertBotSchema>;
export type Bot = typeof botsTable.$inferSelect;
export type BotLog = typeof botLogsTable.$inferSelect;
