import { pgTable, serial, text, real, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tradeSideEnum = pgEnum("trade_side", ["buy", "sell"]);
export const tradeStatusEnum = pgEnum("trade_status", ["open", "closed", "cancelled"]);
export const tradeSourceEnum = pgEnum("trade_source", ["jupiter", "pumpfun"]);

export const tradesTable = pgTable("trades", {
  id: serial("id").primaryKey(),
  tokenMint: text("token_mint").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  tokenName: text("token_name").notNull(),
  side: tradeSideEnum("side").notNull().default("buy"),
  entryPrice: real("entry_price").notNull(),
  exitPrice: real("exit_price"),
  sizeUsd: real("size_usd").notNull(),
  sizeSol: real("size_sol").notNull().default(0),
  slippagePct: real("slippage_pct").notNull().default(10),
  takeProfitPct: real("take_profit_pct").notNull().default(30),
  stopLossPct: real("stop_loss_pct").notNull().default(15),
  status: tradeStatusEnum("status").notNull().default("open"),
  thesis: text("thesis").notNull(),
  source: tradeSourceEnum("source").notNull(),
  pnlUsd: real("pnl_usd"),
  pnlPct: real("pnl_pct"),
  txHash: text("tx_hash"),
  closedAt: timestamp("closed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTradeSchema = createInsertSchema(tradesTable).omit({ id: true, createdAt: true });
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof tradesTable.$inferSelect;
