import { pgTable, serial, real, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const strategyTable = pgTable("strategy", {
  id: serial("id").primaryKey(),
  slippagePct: real("slippage_pct").notNull().default(10),
  defaultTakeProfitPct: real("default_take_profit_pct").notNull().default(30),
  defaultStopLossPct: real("default_stop_loss_pct").notNull().default(15),
  maxPositionPct: real("max_position_pct").notNull().default(20),
  maxOpenPositions: integer("max_open_positions").notNull().default(5),
  compoundFloorPct: real("compound_floor_pct").notNull().default(50),
  autoTakeProfit: boolean("auto_take_profit").notNull().default(true),
  autoStopLoss: boolean("auto_stop_loss").notNull().default(true),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertStrategySchema = createInsertSchema(strategyTable).omit({ id: true, updatedAt: true });
export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Strategy = typeof strategyTable.$inferSelect;
