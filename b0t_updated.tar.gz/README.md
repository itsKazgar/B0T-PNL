# B0T — Solana Smart Trader

A terminal-style automated trading dashboard for scalping JUP and PumpFun tokens on Solana.

Built with React + Vite (frontend), Express 5 (API server + bot engine), PostgreSQL + Drizzle ORM, and the Jupiter Swap API.

---

## Features

- **Live price feeds** via Jupiter Price API (no key required)
- **Paper trading by default** — test strategies without risking real funds
- **Live trading** via Jupiter Swap API when wallet + RPC are configured
- **Automated bots** — PumpFun Scalper, Jupiter DCA, Compound Guard
- **Auto TP/SL enforcement** — monitor closes positions automatically every 30s
- **Compound floor protection** — locks in a percentage of your profits
- **Strategy settings** — slippage, take profit %, stop loss %, floor % all configurable in the UI
- **Full trade history** with P&L, thesis logging, and analytics

---

## Stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Vite, TailwindCSS, Recharts |
| API / Engine | Express 5, Node.js, TypeScript |
| Database | PostgreSQL, Drizzle ORM |
| Solana | `@solana/web3.js`, Jupiter Swap API v6 |
| Monorepo | pnpm workspaces |

---

## Quick Start

### 1. Prerequisites

- Node.js 20+
- pnpm 9+ (`npm install -g pnpm`)
- PostgreSQL database (local or hosted — [Neon](https://neon.tech) free tier works great)

### 2. Clone and install

```bash
git clone https://github.com/your-username/b0t.git
cd b0t
pnpm install
```

### 3. Configure environment

```bash
cp .env.example .env
```

Edit `.env` with your values:

```env
# Required — your PostgreSQL connection string
DATABASE_URL=postgresql://user:password@host:5432/dbname

# Optional — add both to enable live trading (paper mode otherwise)
SOLANA_RPC_URL=https://your-helius-or-quicknode-endpoint
WALLET_PRIVATE_KEY=your-base58-encoded-private-key
```

> **Get a free RPC endpoint:**
> - [Helius](https://helius.dev) — best for Solana, generous free tier
> - [QuickNode](https://quicknode.com) — reliable alternative

> **Wallet key format:** base58 encoded. Export from Phantom: Settings → Security → Export Private Key.
> **Use a dedicated hot wallet** — never your main wallet, only fund it with what you're willing to risk.

### 4. Run migrations

```bash
pnpm --filter @workspace/db run migrate
```

### 5. Start the app

In two terminals:

```bash
# Terminal 1 — API server + bot engine
pnpm --filter @workspace/api-server run dev

# Terminal 2 — Frontend
pnpm --filter @workspace/solana-trader run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## Trading Modes

### Paper mode (default)
Runs automatically when `SOLANA_RPC_URL` or `WALLET_PRIVATE_KEY` are not set. Prices are real (live from Jupiter), but trades are simulated. No real funds move. Use this to test your strategy.

### Live mode
Set both `SOLANA_RPC_URL` and `WALLET_PRIVATE_KEY`. The engine will:
1. Call Jupiter's quote API to find the best swap route
2. Build the transaction via Jupiter's swap API
3. Sign with your wallet key
4. Submit to Solana mainnet via your RPC

The status bar on the Bots page shows `mode: live` in green when active.

---

## Bots

| Bot | Type | What it does |
|---|---|---|
| PumpFun Scalper | `scalper` | Scans trending tokens every 30s, enters on momentum, auto-closes at TP/SL |
| Jupiter DCA | `dca` | Buys a fixed amount of a target token on a regular interval |
| Compound Guard | `compound_guard` | No new trades — just watches all open positions and enforces TP/SL |

Start/stop individual bots from the **Bots** page in the UI.

### Adding a custom bot

1. Add a new row to the `bots` table with your type name
2. Create `artifacts/api-server/src/engine/your-bot.ts` with a `runYourBotTick(botId)` function
3. Call it from `runner.ts` inside the `tick()` function

---

## Strategy Settings

Configurable in the UI under **Strategy**:

| Setting | Default | Description |
|---|---|---|
| Slippage | 10% | Max slippage tolerance on Jupiter swaps |
| Take Profit | +30% | Auto-close long when P&L reaches this |
| Stop Loss | -15% | Auto-close long when P&L drops to this |
| Compound Floor | 50% | Protects this % of unrealised profits |

---

## Project Structure

```
b0t/
├── artifacts/
│   ├── api-server/          # Express API + bot engine
│   │   └── src/
│   │       ├── engine/
│   │       │   ├── runner.ts    # 30s tick loop
│   │       │   ├── monitor.ts   # Auto TP/SL + price updates
│   │       │   ├── scalper.ts   # PumpFun scalper bot
│   │       │   ├── jupiter.ts   # Jupiter swap execution
│   │       │   └── prices.ts    # Jupiter Price API
│   │       └── routes/          # REST API endpoints
│   └── solana-trader/       # React frontend
│       └── src/
│           ├── pages/           # Dashboard, Positions, Bots, Analytics…
│           └── components/      # UI components
├── lib/
│   ├── db/                  # Drizzle ORM schema + migrations
│   └── api-spec/            # OpenAPI spec + generated hooks
└── .env.example
```

---

## Disclaimer

This software is for educational and research purposes. Automated trading carries significant financial risk. Never trade with funds you cannot afford to lose. The authors are not responsible for any financial losses incurred.
