import { Link, useLocation } from "wouter";
import { LayoutDashboard, TrendingUp, Briefcase, List, Layers, BarChart2, Settings, Bot } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/",          label: "Dashboard",     icon: LayoutDashboard },
  { href: "/trade",     label: "New Trade",     icon: TrendingUp },
  { href: "/positions", label: "Positions",     icon: Briefcase },
  { href: "/trades",    label: "History",       icon: List },
  { href: "/tokens",    label: "Tokens",        icon: Layers },
  { href: "/bots",      label: "Bots",          icon: Bot },
  { href: "/analytics", label: "Analytics",     icon: BarChart2 },
  { href: "/strategy",  label: "Strategy",      icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [loc] = useLocation();

  return (
    <div className="flex h-screen w-full bg-background dark text-foreground overflow-hidden">
      {/* Sidebar */}
      <aside className="w-14 md:w-52 border-r border-border bg-sidebar flex flex-col shrink-0">
        {/* Logo */}
        <div className="h-12 flex items-center px-3 md:px-4 border-b border-border">
          <span className="font-mono font-bold text-lg text-primary tracking-widest hidden md:block">B0T</span>
          <span className="font-mono font-bold text-base text-primary md:hidden">B</span>
          <span className="hidden md:block ml-2 text-xs text-muted-foreground font-mono">/solana</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 space-y-0.5 px-2">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = loc === href;
            return (
              <Link key={href} href={href}>
                <div
                  data-testid={`nav-${label.toLowerCase().replace(/\s+/g, '-')}`}
                  className={cn(
                    "flex items-center gap-3 px-2 py-2 rounded text-sm cursor-pointer transition-colors",
                    active
                      ? "bg-primary/15 text-primary font-medium"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  )}
                >
                  <Icon className="size-4 shrink-0" />
                  <span className="hidden md:block font-mono text-xs tracking-wide">{label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Status */}
        <div className="px-3 py-3 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="size-1.5 rounded-full bg-green-500 shrink-0" />
            <span className="hidden md:block font-mono text-xs text-muted-foreground">devnet</span>
          </div>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 h-full overflow-y-auto">
        <div className="max-w-5xl mx-auto p-5 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
