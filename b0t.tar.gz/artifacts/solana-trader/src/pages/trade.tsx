import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import {
  useListJupiterTokens, useListPumpFunTokens, useCreateTrade, useGetStrategy,
  getListPositionsQueryKey, getListTradesQueryKey, getGetPortfolioQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Search, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const schema = z.object({
  tokenMint: z.string().min(1, "select a token"),
  tokenSymbol: z.string().min(1),
  tokenName: z.string().min(1),
  source: z.enum(["jupiter", "pumpfun"]),
  sizeUsd: z.coerce.number().min(1, "enter size"),
  thesis: z.string().min(20, "thesis must be ≥20 chars — why this trade?"),
  takeProfitPct: z.coerce.number().min(1).max(10000),
  stopLossPct: z.coerce.number().min(1).max(100),
  slippagePct: z.coerce.number().min(0.1).max(50),
});
type V = z.infer<typeof schema>;

export default function TradePage() {
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [pumpSort, setPumpSort] = useState<"trending" | "new" | "volume">("trending");
  const { data: strategy } = useGetStrategy();
  const { data: jup } = useListJupiterTokens({ q: search, limit: 15 });
  const { data: pump } = useListPumpFunTokens({ limit: 15, sort: pumpSort });
  const createTrade = useCreateTrade();

  const form = useForm<V>({
    resolver: zodResolver(schema),
    defaultValues: {
      tokenMint: "", tokenSymbol: "", tokenName: "", source: "jupiter",
      sizeUsd: 50, thesis: "",
      takeProfitPct: strategy?.defaultTakeProfitPct ?? 30,
      stopLossPct: strategy?.defaultStopLossPct ?? 15,
      slippagePct: strategy?.slippagePct ?? 10,
    },
  });

  const selectedMint = form.watch("tokenMint");
  const selectedSym = form.watch("tokenSymbol");
  const size = form.watch("sizeUsd");
  const tp = form.watch("takeProfitPct");
  const sl = form.watch("stopLossPct");
  const maxPct = strategy?.maxPositionPct ?? 20;
  const posPct = (size / 500) * 100;

  function pick(t: { mint: string; symbol: string; name: string }, src: "jupiter" | "pumpfun") {
    form.setValue("tokenMint", t.mint);
    form.setValue("tokenSymbol", t.symbol);
    form.setValue("tokenName", t.name);
    form.setValue("source", src);
    form.setValue("takeProfitPct", strategy?.defaultTakeProfitPct ?? 30);
    form.setValue("stopLossPct", strategy?.defaultStopLossPct ?? 15);
    form.setValue("slippagePct", strategy?.slippagePct ?? 10);
  }

  function onSubmit(v: V) {
    createTrade.mutate({ data: v }, {
      onSuccess: () => {
        toast({ title: "trade opened", description: `${v.tokenSymbol} position created` });
        qc.invalidateQueries({ queryKey: getListPositionsQueryKey() });
        qc.invalidateQueries({ queryKey: getListTradesQueryKey() });
        qc.invalidateQueries({ queryKey: getGetPortfolioQueryKey() });
        setLocation("/positions");
      },
      onError: () => toast({ title: "error", description: "trade failed", variant: "destructive" }),
    });
  }

  function TokenList({ tokens, src, change }: { tokens?: { mint: string; symbol: string; name: string; priceUsd: number; change24h?: number | null }[]; src: "jupiter" | "pumpfun"; change: keyof typeof tokens[0] }) {
    return (
      <div className="border border-border divide-y divide-border max-h-72 overflow-y-auto">
        {tokens?.map(t => (
          <div
            key={t.mint}
            className={cn("flex items-center justify-between px-3 py-2.5 cursor-pointer hover:bg-muted/30 transition-colors", selectedMint === t.mint && "bg-primary/10")}
            onClick={() => pick(t, src)}
            data-testid={`token-${t.symbol}`}
          >
            <div>
              <span className="font-mono text-sm font-medium">{t.symbol}</span>
              <span className="font-mono text-xs text-muted-foreground ml-2">{t.name}</span>
            </div>
            <div className="text-right">
              <p className="font-mono text-xs">${t.priceUsd < 0.001 ? t.priceUsd.toFixed(7) : t.priceUsd < 1 ? t.priceUsd.toFixed(4) : t.priceUsd.toFixed(2)}</p>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ new trade</span></h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Token picker */}
        <div className="space-y-3">
          <Tabs defaultValue="jupiter" onValueChange={() => setSearch("")}>
            <TabsList className="w-full grid grid-cols-2 rounded-none h-8">
              <TabsTrigger value="jupiter" className="font-mono text-xs rounded-none">Jupiter</TabsTrigger>
              <TabsTrigger value="pumpfun" className="font-mono text-xs rounded-none">PumpFun</TabsTrigger>
            </TabsList>
            <TabsContent value="jupiter" className="space-y-2 mt-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
                <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="search..." className="pl-8 font-mono text-xs h-8 rounded-none" data-testid="input-search" />
              </div>
              <TokenList tokens={jup?.map(t => ({ ...t, change24h: t.change24h ?? null }))} src="jupiter" change="change24h" />
            </TabsContent>
            <TabsContent value="pumpfun" className="space-y-2 mt-2">
              <div className="flex gap-1">
                {(["trending", "new", "volume"] as const).map(s => (
                  <Button key={s} variant={pumpSort === s ? "default" : "ghost"} size="sm" className="font-mono text-xs h-7 rounded-none px-2" onClick={() => setPumpSort(s)}>{s}</Button>
                ))}
              </div>
              <TokenList tokens={pump?.map(t => ({ ...t, change24h: t.change1h ?? null }))} src="pumpfun" change="change1h" />
            </TabsContent>
          </Tabs>
        </div>

        {/* Form */}
        <div className="border border-border bg-card p-5">
          <p className="font-mono text-xs text-muted-foreground mb-4">
            {selectedMint ? `trading: ${selectedSym}` : "select a token"}
          </p>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="sizeUsd" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground">size (usd)</FormLabel>
                  <FormControl><Input {...field} type="number" className="font-mono text-sm h-8 rounded-none" data-testid="input-size" /></FormControl>
                  {size > 0 && (
                    <p className={cn("font-mono text-xs", posPct > maxPct ? "text-yellow-400 flex items-center gap-1" : "text-muted-foreground")}>
                      {posPct > maxPct && <AlertTriangle className="size-3" />}
                      {posPct.toFixed(1)}% of portfolio {posPct > maxPct ? `— exceeds max ${maxPct}%` : ""}
                    </p>
                  )}
                  <FormMessage className="font-mono text-xs" />
                </FormItem>
              )} />

              <div className="grid grid-cols-3 gap-2">
                {[
                  { name: "takeProfitPct" as const, label: "tp %" },
                  { name: "stopLossPct" as const, label: "sl %" },
                  { name: "slippagePct" as const, label: "slip %" },
                ].map(({ name, label }) => (
                  <FormField key={name} control={form.control} name={name} render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs text-muted-foreground">{label}</FormLabel>
                      <FormControl><Input {...field} type="number" className="font-mono text-xs h-8 rounded-none" data-testid={`input-${name}`} /></FormControl>
                      <FormMessage className="font-mono text-xs" />
                    </FormItem>
                  )} />
                ))}
              </div>

              {tp > 0 && sl > 0 && size > 0 && (
                <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                  <div className="border border-green-500/20 bg-green-500/5 p-2">
                    <p className="text-muted-foreground">take profit</p>
                    <p className="profit font-medium mt-0.5">+${((tp / 100) * size).toFixed(2)}</p>
                  </div>
                  <div className="border border-red-500/20 bg-red-500/5 p-2">
                    <p className="text-muted-foreground">max loss</p>
                    <p className="loss font-medium mt-0.5">-${((sl / 100) * size).toFixed(2)}</p>
                  </div>
                </div>
              )}

              <FormField control={form.control} name="thesis" render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground">thesis <span className="text-destructive">*</span></FormLabel>
                  <FormControl>
                    <Textarea {...field} rows={3} placeholder="why are you taking this trade?" className="font-mono text-xs rounded-none resize-none" data-testid="textarea-thesis" />
                  </FormControl>
                  <div className="flex justify-between items-center">
                    <FormMessage className="font-mono text-xs" />
                    <span className={cn("font-mono text-xs ml-auto", field.value.length >= 20 ? "text-muted-foreground" : "text-destructive")}>{field.value.length}/20</span>
                  </div>
                </FormItem>
              )} />

              <Button type="submit" className="w-full font-mono text-xs h-9 rounded-none" disabled={!selectedMint || createTrade.isPending} data-testid="button-submit">
                {createTrade.isPending ? "executing..." : selectedMint ? `buy ${selectedSym} — $${size}` : "select a token first"}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
