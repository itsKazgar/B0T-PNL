import { useState } from "react";
import { useListJupiterTokens, useListPumpFunTokens } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

const fmt = (n: number) => n >= 1e9 ? `${(n/1e9).toFixed(2)}B` : n >= 1e6 ? `${(n/1e6).toFixed(1)}M` : n >= 1e3 ? `${(n/1e3).toFixed(0)}K` : n.toFixed(2);

export default function TokensPage() {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"trending" | "new" | "volume">("trending");
  const { data: jup, isLoading: jl } = useListJupiterTokens({ q, limit: 20 });
  const { data: pump, isLoading: pl } = useListPumpFunTokens({ limit: 20, sort });

  return (
    <div className="space-y-6">
      <h1 className="font-mono text-xl font-bold">B0T <span className="text-muted-foreground font-normal text-sm">/ tokens</span></h1>

      <Tabs defaultValue="jupiter">
        <TabsList className="rounded-none h-8 grid w-fit grid-cols-2">
          <TabsTrigger value="jupiter" className="font-mono text-xs rounded-none px-6">Jupiter</TabsTrigger>
          <TabsTrigger value="pumpfun" className="font-mono text-xs rounded-none px-6">PumpFun</TabsTrigger>
        </TabsList>

        <TabsContent value="jupiter" className="mt-4 space-y-3">
          <div className="relative max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
            <Input value={q} onChange={e => setQ(e.target.value)} placeholder="search..." className="pl-8 h-8 font-mono text-xs rounded-none" data-testid="input-jup-search" />
          </div>
          {jl ? <Skeleton className="h-64" /> : (
            <div className="border border-border divide-y divide-border">
              <div className="grid grid-cols-12 px-4 py-2 font-mono text-xs text-muted-foreground uppercase tracking-widest">
                <span className="col-span-4">token</span>
                <span className="col-span-2 text-right">price</span>
                <span className="col-span-2 text-right">24h</span>
                <span className="col-span-2 text-right">mcap</span>
                <span className="col-span-2 text-right" />
              </div>
              {jup?.map(t => (
                <div key={t.mint} className="grid grid-cols-12 px-4 py-2.5 font-mono text-xs hover:bg-muted/20 transition-colors items-center" data-testid={`row-jup-${t.symbol}`}>
                  <div className="col-span-4"><p className="font-medium">{t.symbol}</p><p className="text-muted-foreground">{t.name}</p></div>
                  <span className="col-span-2 text-right">${t.priceUsd < 0.001 ? t.priceUsd.toFixed(7) : t.priceUsd < 1 ? t.priceUsd.toFixed(4) : t.priceUsd.toFixed(2)}</span>
                  <span className={cn("col-span-2 text-right", t.change24h !== null && t.change24h !== undefined ? (t.change24h >= 0 ? "profit" : "loss") : "text-muted-foreground")}>
                    {t.change24h !== null && t.change24h !== undefined ? `${t.change24h >= 0 ? "+" : ""}${t.change24h.toFixed(1)}%` : "—"}
                  </span>
                  <span className="col-span-2 text-right text-muted-foreground">{fmt(t.marketCap)}</span>
                  <div className="col-span-2 text-right">
                    <Link href="/trade"><Button variant="ghost" size="sm" className="h-6 font-mono text-xs rounded-none px-2">trade</Button></Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="pumpfun" className="mt-4 space-y-3">
          <div className="flex gap-1">
            {(["trending", "new", "volume"] as const).map(s => (
              <Button key={s} variant={sort === s ? "default" : "ghost"} size="sm" className="h-7 font-mono text-xs rounded-none px-3" onClick={() => setSort(s)} data-testid={`btn-sort-${s}`}>{s}</Button>
            ))}
          </div>
          {pl ? <Skeleton className="h-64" /> : (
            <div className="border border-border divide-y divide-border">
              <div className="grid grid-cols-12 px-4 py-2 font-mono text-xs text-muted-foreground uppercase tracking-widest">
                <span className="col-span-4">token</span>
                <span className="col-span-2 text-right">price</span>
                <span className="col-span-2 text-right">1h</span>
                <span className="col-span-2 text-right">mcap</span>
                <span className="col-span-2 text-right">bonding</span>
              </div>
              {pump?.map(t => (
                <div key={t.mint} className="grid grid-cols-12 px-4 py-2.5 font-mono text-xs hover:bg-muted/20 transition-colors items-center" data-testid={`row-pump-${t.symbol}`}>
                  <div className="col-span-4"><p className="font-medium text-orange-300">{t.symbol}</p><p className="text-muted-foreground truncate">{t.name}</p></div>
                  <span className="col-span-2 text-right">${t.priceUsd < 0.001 ? t.priceUsd.toFixed(7) : t.priceUsd < 1 ? t.priceUsd.toFixed(4) : t.priceUsd.toFixed(2)}</span>
                  <span className={cn("col-span-2 text-right", t.change1h !== null && t.change1h !== undefined ? (t.change1h >= 0 ? "profit" : "loss") : "text-muted-foreground")}>
                    {t.change1h !== null && t.change1h !== undefined ? `${t.change1h >= 0 ? "+" : ""}${t.change1h.toFixed(1)}%` : "—"}
                  </span>
                  <span className="col-span-2 text-right text-muted-foreground">{fmt(t.marketCap)}</span>
                  <div className="col-span-2 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <div className="w-10 h-1 bg-muted overflow-hidden"><div className="h-full bg-orange-500/70" style={{ width: `${Math.min(t.bondingCurvePct, 100)}%` }} /></div>
                      <span className="text-muted-foreground">{t.bondingCurvePct.toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
