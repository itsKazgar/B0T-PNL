const JUPITER_PRICE_URL = "https://api.jup.ag/price/v2";
const SOL_MINT = "So11111111111111111111111111111111111111112";

// Cache prices for 20s to avoid hammering Jupiter
let priceCache: { prices: Record<string, number>; ts: number } = { prices: {}, ts: 0 };

export async function fetchPrices(mints: string[]): Promise<Record<string, number>> {
  if (!mints.length) return {};
  // Trim whitespace from mints — DB entries can sometimes have trailing spaces
  const allMints = Array.from(new Set([...mints.map(m => m.trim()), SOL_MINT]));
  try {
    const res = await fetch(`${JUPITER_PRICE_URL}?ids=${allMints.join(",")}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) throw new Error(`Jupiter price API ${res.status}`);
    const json = (await res.json()) as { data: Record<string, { price: number }> };
    const prices: Record<string, number> = {};
    for (const [mint, data] of Object.entries(json.data ?? {})) {
      if (data?.price) prices[mint] = data.price;
    }
    priceCache = { prices, ts: Date.now() };
    return prices;
  } catch (err) {
    // Return cached if available
    if (priceCache.ts > 0) return priceCache.prices;
    throw err;
  }
}

export function getSolPrice(): number {
  return priceCache.prices[SOL_MINT] ?? 150;
}
